package claudebuddy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.block.state.BlockState;

/** Simpele A* padzoeker over blokken: lopen, 1 blok omhoog stappen, tot 3 blokken naar beneden. */
public final class PathFinder {
	private static final int MAX_NODES = 6000;
	private static final int MAX_RANGE = 72;
	private static final int[][] DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

	public static final class Result {
		public final List<int[]> nodes;
		public final boolean complete;

		Result(List<int[]> nodes, boolean complete) {
			this.nodes = nodes;
			this.complete = complete;
		}
	}

	private static final class Node {
		final int x;
		final int y;
		final int z;
		final double g;
		final double f;
		final Node parent;

		Node(int x, int y, int z, double g, double f, Node parent) {
			this.x = x;
			this.y = y;
			this.z = z;
			this.g = g;
			this.f = f;
			this.parent = parent;
		}
	}

	private final ServerLevel level;
	private final Map<Long, Byte> cache = new HashMap<>();

	private PathFinder(ServerLevel level) {
		this.level = level;
	}

	private static long key(int x, int y, int z) {
		return (((long) x & 0x3FFFFFFL) << 38) | (((long) z & 0x3FFFFFFL) << 12) | ((long) y & 0xFFFL);
	}

	/** 0 = vrij (je kan erdoor), 1 = vast (je kan erop staan), 2 = lava of niet geladen, 3 = water (zwemmen). */
	private byte kind(int x, int y, int z) {
		long k = key(x, y, z);
		Byte cached = cache.get(k);

		if (cached != null) {
			return cached;
		}

		byte result = kindOf(level, new BlockPos(x, y, z));
		cache.put(k, result);
		return result;
	}

	public static byte kindOf(ServerLevel level, BlockPos pos) {
		if (!level.isLoaded(pos)) {
			return 2;
		}

		BlockState state = level.getBlockState(pos);

		if (!state.getFluidState().isEmpty()) {
			return state.getFluidState().is(FluidTags.WATER) ? (byte) 3 : (byte) 2;
		}

		if (isWoodenDoor(state)) {
			return 0; // deuren doet Claude zelf open
		}

		// dunne laagjes waar je gewoon overheen loopt: sneeuwlaag, tapijt
		String id = BuiltInRegistries.BLOCK.getKey(state.getBlock()).toString();

		if (id.equals("minecraft:snow") || id.endsWith("_carpet")) {
			return 0;
		}

		return state.getCollisionShape(level, pos).isEmpty() ? (byte) 0 : (byte) 1;
	}

	public static boolean isWoodenDoor(BlockState state) {
		String id = BuiltInRegistries.BLOCK.getKey(state.getBlock()).toString();
		return id.endsWith("_door") && !id.contains("iron");
	}

	/** Lucht of water: daar past Claude doorheen. */
	private boolean free(int x, int y, int z) {
		byte k = kind(x, y, z);
		return k == 0 || k == 3;
	}

	/** Staan op een blok, of drijven/zwemmen in water. */
	private boolean standable(int x, int y, int z) {
		if (!free(x, y, z) || !free(x, y + 1, z)) {
			return false;
		}

		byte below = kind(x, y - 1, z);
		return below == 1 || kind(x, y, z) == 3;
	}

	/** Kan Claude hier staan? (voeten op x,y,z) */
	public static boolean canStand(ServerLevel level, int x, int y, int z) {
		return bodyFits(level, x, y, z) && kindOf(level, new BlockPos(x, y - 1, z)) == 1;
	}

	/** Is er nog ruimte voor Claude's lijf op deze plek? */
	public static boolean bodyFits(ServerLevel level, int x, int y, int z) {
		byte a = kindOf(level, new BlockPos(x, y, z));
		byte b = kindOf(level, new BlockPos(x, y + 1, z));
		return (a == 0 || a == 3) && (b == 0 || b == 3);
	}

	/**
	 * Zoek een pad van start naar (dichtbij) doel.
	 * tolerance = hoe dicht bij het doel goed genoeg is (in blokken).
	 * Als het doel niet te bereiken is krijg je het pad naar de plek die er het dichtst bij komt.
	 */
	public static Result find(ServerLevel level, int sx, int sy, int sz, int gx, int gy, int gz, double tolerance) {
		PathFinder finder = new PathFinder(level);
		return finder.search(sx, sy, sz, gx, gy, gz, tolerance);
	}

	private static double dist(int x, int y, int z, int gx, int gy, int gz) {
		double dx = x - gx;
		double dy = y - gy;
		double dz = z - gz;
		return Math.sqrt(dx * dx + dy * dy + dz * dz);
	}

	private Result search(int sx, int sy, int sz, int gx, int gy, int gz, double tolerance) {
		PriorityQueue<Node> open = new PriorityQueue<>((a, b) -> Double.compare(a.f, b.f));
		Map<Long, Double> best = new HashMap<>();
		Node start = new Node(sx, sy, sz, 0, dist(sx, sy, sz, gx, gy, gz), null);
		open.add(start);
		best.put(key(sx, sy, sz), 0.0);

		Node closest = start;
		double closestDist = dist(sx, sy, sz, gx, gy, gz);
		int expanded = 0;

		while (!open.isEmpty() && expanded < MAX_NODES) {
			Node n = open.poll();
			Double known = best.get(key(n.x, n.y, n.z));

			if (known != null && known < n.g) {
				continue;
			}

			expanded++;
			double d = dist(n.x, n.y, n.z, gx, gy, gz);

			if (d < closestDist) {
				closestDist = d;
				closest = n;
			}

			if (d <= tolerance) {
				return new Result(build(n), true);
			}

			for (int[] dir : DIRS) {
				int tx = n.x + dir[0];
				int tz = n.z + dir[1];
				int ty = Integer.MIN_VALUE;
				double cost = 1.0;

				if (standable(tx, n.y, tz)) {
					ty = n.y;
				} else if (free(n.x, n.y + 2, n.z) && standable(tx, n.y + 1, tz)) {
					ty = n.y + 1;
					cost = 1.6;
				} else if (free(tx, n.y, tz) && free(tx, n.y + 1, tz)) {
					for (int drop = 1; drop <= 3; drop++) {
						if (standable(tx, n.y - drop, tz)) {
							ty = n.y - drop;
							cost = 1.0 + drop * 0.5;
							break;
						}

						if (!free(tx, n.y - drop, tz)) {
							break;
						}
					}
				}

				if (ty == Integer.MIN_VALUE) {
					continue;
				}

				if (Math.abs(tx - sx) > MAX_RANGE || Math.abs(tz - sz) > MAX_RANGE) {
					continue;
				}

				if (kind(tx, ty, tz) == 3) {
					cost += kind(tx, ty + 1, tz) == 3 ? 3.0 : 1.0;
				}

				double g = n.g + cost;
				long k = key(tx, ty, tz);
				Double old = best.get(k);

				if (old != null && old <= g) {
					continue;
				}

				best.put(k, g);
				open.add(new Node(tx, ty, tz, g, g + dist(tx, ty, tz, gx, gy, gz), n));
			}
		}

		return new Result(build(closest), false);
	}

	private static List<int[]> build(Node end) {
		List<int[]> nodes = new ArrayList<>();

		for (Node n = end; n != null; n = n.parent) {
			nodes.add(new int[] {n.x, n.y, n.z});
		}

		Collections.reverse(nodes);
		return nodes;
	}
}
