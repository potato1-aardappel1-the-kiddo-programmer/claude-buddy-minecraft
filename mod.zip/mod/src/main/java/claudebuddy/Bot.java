package claudebuddy;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.regex.Pattern;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.Container;
import net.minecraft.world.Difficulty;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.gamerules.GameRules;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Het brein van Claude's poppetje in de wereld.
 * Alles hier draait op de server-thread van Minecraft.
 */
public final class Bot {
	/** Vaste UUID van Claude's poppetje, zodat we hem altijd terugvinden. */
	public static final UUID BOT_UUID = UUID.fromString("c1a0de00-b0b0-4c1a-8de0-0000c1a0de01");

	private static final Pattern PLAYER_NAME = Pattern.compile("[A-Za-z0-9_]{1,16}");
	private static final Pattern BLOCK_SPEC = Pattern.compile("[a-z0-9_.:/-]+(\\[[a-z0-9_=,]*\\])?");
	private static final Pattern ITEM_SPEC = Pattern.compile("[a-z0-9_.:/-]+");

	private static final double REACH = 5.5;
	private static final double DANGER_RANGE = 16.0;

	private final MinecraftServer server;
	private final ConcurrentLinkedDeque<JsonObject> events = new ConcurrentLinkedDeque<>();
	private final Map<String, Integer> inventory = new TreeMap<>();
	private final Set<UUID> knownThreats = new HashSet<>();

	// instellingen
	// standaard uit: Claude houdt zich aan de regels van de wereld en bouwt alleen met wat hij zelf gehakt heeft
	private boolean infiniteBlocks = false;
	// spelmodus van Claude: creatief = vliegen, onkwetsbaar en bouwen zonder blokken te hebben
	private volatile boolean creative = false;
	private double[] flyTarget = null;
	// honger: 20 = vol. Telt alleen in survival en niet op vredig
	private int food = 20;
	private float saturation = 5f;
	private float exhaustion = 0f;
	private boolean autoEat = true;
	private boolean hungerWarned = false;
	private double lastHungerX = Double.NaN;
	private double lastHungerZ = 0;
	// schild omhoog: klappen van wezens en spelers tellen dan niet
	private volatile boolean blocking = false;
	// ingedrukte knoppen die vanzelf weer los moeten: x, y, z, tik
	private final List<int[]> buttonResets = new ArrayList<>();
	private boolean defend = true;
	// mag ik een speler slaan? Standaard uit, alleen aan als de speler er zelf om vraagt
	private boolean hitPlayers = false;
	private boolean warnInChat = true;

	// lopen
	private List<int[]> path = null;
	private int pathIndex = 0;
	private double speed = 0.22;
	private int goalX;
	private int goalY;
	private int goalZ;
	private double goalTolerance = 1.5;
	private int repaths = 0;

	// volgen
	private String followName = null;
	private int followFails = 0;

	private int lastWarnTick = -10000;
	private int lastAttackTick = -10000;

	// leven, springen, vasthouden
	private boolean deathHandled = false;
	private boolean madeVulnerable = false;
	private float lastHealth = -1f;
	private int jumpTick = -1;
	private double jumpBaseY = 0;
	private String heldItem = "";

	// de oranje doos die na mijn dood mijn spullen naar de speler brengt
	private static final UUID BOX_UUID = UUID.fromString("c1a0de00-b0b0-4c1a-8de0-0000c1a0de02");
	private final Map<String, Integer> boxItems = new TreeMap<>();
	private String boxPlayer = null;
	private int boxPhase = -1; // -1 = geen doos, 0 = vliegt, >0 = is open
	private int boxTicks = 0;

	// harnas dat ik aan heb: slot -> item
	private final Map<String, String> worn = new HashMap<>();
	private static final String[][] ARMOR_SLOTS = {
			{"armor.head", "_helmet", "hoofd"}, {"armor.chest", "_chestplate", "borst"},
			{"armor.legs", "_leggings", "benen"}, {"armor.feet", "_boots", "voeten"}};

	// vastzitten
	private int stuckChecks = 0;
	private int lastUnstuckTick = -10000;
	private String lastEventKey = "";
	private int lastEventTick = -10000;

	// slapen
	private boolean sleeping = false;
	private boolean playerWasSleeping = false;
	private int[] bedPos = null;

	// inventaris bewaren in de wereldmap, zodat hij niet weg is na afsluiten
	private String savedInventory = "";

	private static final double[] JUMP_CURVE = {0.42, 0.75, 1.0, 1.17, 1.25, 1.25, 1.17, 1.0, 0.75, 0.42};

	public Bot(MinecraftServer server) {
		this.server = server;
		loadInventory();
	}

	private Path inventoryFile() {
		return server.getWorldPath(LevelResource.ROOT).resolve("claudebuddy_inventaris.json");
	}

	private void loadInventory() {
		try {
			Path file = inventoryFile();

			if (Files.exists(file)) {
				String text = Files.readString(file, StandardCharsets.UTF_8);
				JsonObject o = JsonParser.parseString(text).getAsJsonObject();

				for (Map.Entry<String, JsonElement> en : o.entrySet()) {
					inventory.put(en.getKey(), en.getValue().getAsInt());
				}

				savedInventory = inventoryJson();
			}
		} catch (Exception e) {
			ClaudeBuddy.LOGGER.warn("Inventaris van Claude laden lukte niet: {}", e.toString());
		}
	}

	private String inventoryJson() {
		JsonObject o = new JsonObject();

		for (Map.Entry<String, Integer> en : inventory.entrySet()) {
			o.addProperty(en.getKey(), en.getValue());
		}

		return o.toString();
	}

	private void saveInventoryIfChanged() {
		String now = inventoryJson();

		if (now.equals(savedInventory)) {
			return;
		}

		try {
			Files.writeString(inventoryFile(), now, StandardCharsets.UTF_8);
			savedInventory = now;
		} catch (Exception e) {
			ClaudeBuddy.LOGGER.warn("Inventaris van Claude opslaan lukte niet: {}", e.toString());
		}
	}

	private Entity findByUuid(UUID uuid) {
		for (ServerLevel level : server.getAllLevels()) {
			Entity e = level.getEntity(uuid);

			if (e != null) {
				return e;
			}
		}

		return null;
	}

	// ------------------------------------------------------------------
	// hulpjes
	// ------------------------------------------------------------------

	private Entity find() {
		for (ServerLevel level : server.getAllLevels()) {
			Entity e = level.getEntity(BOT_UUID);

			if (e != null && e.isAlive()) {
				return e;
			}
		}

		return null;
	}

	private Entity findRaw() {
		for (ServerLevel level : server.getAllLevels()) {
			Entity e = level.getEntity(BOT_UUID);

			if (e != null) {
				return e;
			}
		}

		return null;
	}

	private void command(String command) {
		server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(), command);
	}

	/** Voert een commando uit op de plek (en in de dimensie) van Claude. */
	private void commandAsBot(String command) {
		command("execute as " + BOT_UUID + " at @s run " + command);
	}

	private static double r1(double v) {
		return Math.round(v * 10.0) / 10.0;
	}

	private static String blockId(BlockState state) {
		return BuiltInRegistries.BLOCK.getKey(state.getBlock()).toString();
	}

	private static String entityId(Entity e) {
		return BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).toString();
	}

	private static String direction(double dx, double dz) {
		if (dx * dx + dz * dz < 0.25) {
			return "hier";
		}

		double angle = Math.toDegrees(Math.atan2(dx, -dz));

		if (angle < 0) {
			angle += 360;
		}

		String[] names = {"noord", "noordoost", "oost", "zuidoost", "zuid", "zuidwest", "west", "noordwest"};
		return names[(int) Math.round(angle / 45.0) % 8];
	}

	private static JsonArray posArray(double x, double y, double z) {
		JsonArray a = new JsonArray();
		a.add(r1(x));
		a.add(r1(y));
		a.add(r1(z));
		return a;
	}

	private static JsonArray posArray(int x, int y, int z) {
		JsonArray a = new JsonArray();
		a.add(x);
		a.add(y);
		a.add(z);
		return a;
	}

	private static int i(JsonObject o, String name) {
		if (!o.has(name)) {
			throw new IllegalArgumentException("Ik mis het getal '" + name + "'.");
		}

		return (int) Math.floor(o.get(name).getAsDouble());
	}

	private static String s(JsonObject o, String name, String fallback) {
		return o.has(name) && !o.get(name).isJsonNull() ? o.get(name).getAsString() : fallback;
	}

	private void event(JsonObject e) {
		String key = e.toString();
		int now = server.getTickCount();

		if (key.equals(lastEventKey) && now - lastEventTick < 100 && !key.contains("\"chat\"")) {
			return;
		}

		lastEventKey = key;
		lastEventTick = now;
		e.addProperty("tick", server.getTickCount());
		events.add(e);

		while (events.size() > 200) {
			events.pollFirst();
		}
	}

	private void simpleEvent(String type, String text) {
		JsonObject e = new JsonObject();
		e.addProperty("type", type);
		e.addProperty("tekst", text);
		event(e);
	}

	public void onChat(String player, String text) {
		JsonObject e = new JsonObject();
		e.addProperty("type", "chat");
		e.addProperty("speler", player);
		e.addProperty("tekst", text);
		event(e);
	}

	private void say(String text) {
		String clean = text.replaceAll("[\\r\\n\\t]+", " ").trim();

		if (clean.length() > 240) {
			clean = clean.substring(0, 240);
		}

		if (!clean.isEmpty()) {
			server.getPlayerList().broadcastSystemMessage(Component.literal("<Claude> " + clean), false);
		}
	}

	private void face(Entity bot, double dx, double dy, double dz) {
		double h = Math.sqrt(dx * dx + dz * dz);

		if (h < 1.0e-4 && Math.abs(dy) < 1.0e-4) {
			return;
		}

		if (h >= 1.0e-4) {
			float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
			bot.setYRot(yaw);
			bot.setYHeadRot(yaw);
			bot.setYBodyRot(yaw);
		}

		float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.max(h, 1.0e-4)));
		bot.setXRot(Math.max(-89f, Math.min(89f, pitch)));
	}

	private void lookAt(Entity bot, double x, double y, double z) {
		Vec3 eye = bot.getEyePosition();
		face(bot, x - eye.x, y - eye.y, z - eye.z);
	}

	private ServerPlayer playerOrNearest(Entity bot, String name) {
		if (name != null && !name.isEmpty()) {
			if (!PLAYER_NAME.matcher(name).matches()) {
				throw new IllegalArgumentException("Rare spelernaam: " + name);
			}

			ServerPlayer p = server.getPlayerList().getPlayerByName(name);

			if (p == null) {
				throw new IllegalArgumentException("Speler " + name + " is niet online.");
			}

			return p;
		}

		List<ServerPlayer> players = server.getPlayerList().getPlayers();

		if (players.isEmpty()) {
			throw new IllegalArgumentException("Er is niemand online.");
		}

		if (bot == null) {
			return players.get(0);
		}

		ServerPlayer best = null;
		double bestDist = Double.MAX_VALUE;

		for (ServerPlayer p : players) {
			double d = p.level() == bot.level() ? p.distanceTo(bot) : 1.0e9;

			if (d < bestDist) {
				bestDist = d;
				best = p;
			}
		}

		return best;
	}

	// ------------------------------------------------------------------
	// elke tick
	// ------------------------------------------------------------------

	public void tick() {
		if (server.getTickCount() % 40 == 0) {
			saveInventoryIfChanged();
		}

		if (boxPhase >= 0) {
			try {
				boxStep();
			} catch (Throwable t) {
				ClaudeBuddy.LOGGER.error("Claude's doos ging mis", t);
				boxPhase = -1;
			}
		}

		Entity raw = findRaw();

		if (raw != null && !raw.isAlive()) {
			if (!deathHandled) {
				deathHandled = true;
				onDeath(raw);
			}

			return;
		}

		Entity bot = raw;

		if (bot == null) {
			return;
		}

		deathHandled = false;
		ServerLevel level = (ServerLevel) bot.level();
		int tick = server.getTickCount();

		if (!madeVulnerable) {
			// oudere Claude-poppetjes waren onkwetsbaar: nu kan je me gewoon meppen
			madeVulnerable = true;
			command("data merge entity " + BOT_UUID + " {Invulnerable:0b}");
		}

		if (bot instanceof LivingEntity living) {
			float health = living.getHealth();

			if (lastHealth >= 0 && health < lastHealth - 0.01f) {
				JsonObject ev = new JsonObject();
				ev.addProperty("type", "au");
				ev.addProperty("tekst", "Ik ben geraakt!");
				ev.addProperty("levens", r1(health));
				event(ev);

				if (sleeping) {
					wake(bot, level, false);
				}
			}

			lastHealth = health;
		}

		if (tick % 4 == 0) {
			pickUpItems(bot, level);
		}

		if (tick % 20 == 0) {
			wearBestArmor();
		}

		if (tick % 10 == 0) {
			watchSleep(bot, level);
		}

		hungerTick(bot, level, tick);

		if (!buttonResets.isEmpty()) {
			buttonTick(level, tick);
		}

		if (sleeping) {
			// zonder zwaartekracht blijft elk duwtje eeuwig doorgaan: daarom lig ik elke tik weer vast op het bed
			if (bedPos != null) {
				bot.setDeltaMovement(Vec3.ZERO);
				bot.setPos(bedPos[0] + 0.5, bedPos[1] + 0.6875, bedPos[2] + 0.5);
			}

			if (tick % 10 == 0) {
				dangerScan(bot, level, tick);
			}

			return;
		}

		if (bot.isPassenger()) {
			// ik zit ergens op (kussen, boot, dier): dan beweeg ik zelf niet
			path = null;
			flyTarget = null;
			jumpTick = -1;

			if (tick % 10 == 0) {
				dangerScan(bot, level, tick);
			}

			return;
		}

		if (tick % 5 == 0 && jumpTick < 0) {
			unstuck(bot, level);
		}

		if (jumpTick >= 0) {
			jumpStep(bot);
			return;
		}

		if (followName != null && tick % 10 == 0) {
			followStep(bot, level);
		}

		if (flyTarget != null) {
			flyStep(bot, level);
		} else if (path != null) {
			moveStep(bot, level);
		} else {
			floatInWater(bot, level);

			if (tick % 2 == 0) {
				idleLook(bot, level);
			}
		}

		if (tick % 10 == 0) {
			dangerScan(bot, level, tick);
		}
	}

	// ---------------- spelmodus (creatief / survival) ----------------

	/** Voor het commando /gamemodeclaude en de instelling 'creatief'. Geeft een zin terug voor de speler. */
	public String gameMode(String mode) {
		String m = mode == null ? "" : mode.toLowerCase(Locale.ROOT);
		boolean wantCreative;

		if (m.equals("c") || m.equals("creative") || m.equals("creatief") || m.equals("1")) {
			wantCreative = true;
		} else if (m.equals("s") || m.equals("survival") || m.equals("0")) {
			wantCreative = false;
		} else {
			return "Kies c (creatief) of s (survival). Claude staat nu op " + (creative ? "creatief" : "survival") + ".";
		}

		creative = wantCreative;
		infiniteBlocks = wantCreative;
		flyTarget = null;
		Entity bot = find();

		if (bot != null) {
			if (!wantCreative) {
				landSafely(bot, (ServerLevel) bot.level());
			}

			applyModeFlags();
		}

		simpleEvent("spelmodus", wantCreative
				? "Ik sta nu op creatief: ik kan vliegen, ga niet dood en mag alle blokken gebruiken."
				: "Ik sta nu op survival: lopen, gewoon kwetsbaar en alleen blokken die ik zelf heb.");
		return wantCreative ? "Claude staat nu op creatief (vliegen, onkwetsbaar, alle blokken)."
				: "Claude staat nu op survival.";
	}

	private void applyModeFlags() {
		command("data merge entity " + BOT_UUID + " {Invulnerable:" + (creative ? 1 : 0) + "b,NoGravity:" + (creative ? 1 : 0) + "b}");
	}

	/** Terug naar survival terwijl ik in de lucht hang: eerst rustig op de grond zetten, anders val ik te pletter. */
	private void landSafely(Entity bot, ServerLevel level) {
		BlockPos p = bot.blockPosition();

		for (int y = p.getY(); y > p.getY() - 320; y--) {
			if (PathFinder.canStand(level, p.getX(), y, p.getZ())) {
				bot.setDeltaMovement(Vec3.ZERO);
				bot.setPos(p.getX() + 0.5, y, p.getZ() + 0.5);
				return;
			}
		}
	}

	private JsonObject fly(Entity bot, int x, int y, int z) {
		path = null;
		flyTarget = new double[] {x + 0.5, y, z + 0.5};
		JsonObject o = msg("Ik vlieg erheen.");
		o.addProperty("pad_compleet", true);
		return o;
	}

	private void flyStep(Entity bot, ServerLevel level) {
		double dx = flyTarget[0] - bot.getX();
		double dy = flyTarget[1] - bot.getY();
		double dz = flyTarget[2] - bot.getZ();
		double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
		double step = speed * 2.5;
		bot.setDeltaMovement(Vec3.ZERO);

		if (d <= step) {
			bot.setPos(flyTarget[0], flyTarget[1], flyTarget[2]);
			BlockPos at = bot.blockPosition();
			flyTarget = null;

			if (followName == null) {
				simpleEvent("aangekomen", "Ik ben aangekomen op " + at.getX() + " " + at.getY() + " " + at.getZ() + ".");
			}

			return;
		}

		double nx = bot.getX() + dx / d * step;
		double ny = bot.getY() + dy / d * step;
		double nz = bot.getZ() + dz / d * step;

		if (!PathFinder.bodyFits(level, (int) Math.floor(nx), (int) Math.floor(ny), (int) Math.floor(nz))) {
			flyTarget = null;
			simpleEvent("vastgelopen", "Er zit een blok in de weg, ik vlieg niet verder.");
			return;
		}

		face(bot, dx, 0, dz);
		bot.setPos(nx, ny, nz);
	}

	private void moveStep(Entity bot, ServerLevel level) {
		int[] node = path.get(pathIndex);
		openDoor(level, new BlockPos(node[0], node[1], node[2]));

		if (!PathFinder.bodyFits(level, node[0], node[1], node[2])) {
			// er staat ineens een blok in de weg: nieuw pad zoeken
			if (repaths < 4 && startPath(bot, level, goalX, goalY, goalZ, goalTolerance) != null) {
				repaths++;
				return;
			}

			path = null;
			simpleEvent("vastgelopen", "Ik kan niet verder lopen, er zit iets in de weg.");
			return;
		}

		double tx = node[0] + 0.5;
		double ty = node[1];
		double tz = node[2] + 0.5;
		double x = bot.getX();
		double y = bot.getY();
		double z = bot.getZ();
		double dx = tx - x;
		double dz = tz - z;
		double h = Math.sqrt(dx * dx + dz * dz);

		if (h <= speed) {
			bot.setPos(tx, ty, tz);
			pathIndex++;

			if (pathIndex >= path.size()) {
				path = null;

				if (followName == null) {
					simpleEvent("aangekomen", "Ik ben aangekomen op " + node[0] + " " + node[1] + " " + node[2] + ".");
				}
			}

			return;
		}

		// omhoog stappen doen we meteen (sprongetje), naar beneden pas als we er zijn
		double ny = ty > y ? ty : y;
		face(bot, dx, 0, dz);
		bot.setPos(x + dx / h * speed, ny, z + dz / h * speed);
	}

	private static String uuidNbt(UUID uuid) {
		long msb = uuid.getMostSignificantBits();
		long lsb = uuid.getLeastSignificantBits();
		return "UUID:[I;" + (int) (msb >> 32) + "," + (int) msb + "," + (int) (lsb >> 32) + "," + (int) lsb + "]";
	}

	/** Laat spullen als echte items op de grond vallen bij een entity (Claude of de doos). */
	private static String at(Entity e) {
		return String.format(Locale.ROOT, "execute in %s positioned %.2f %.2f %.2f run ",
				((ServerLevel) e.level()).dimension().identifier().toString(), e.getX(), e.getY(), e.getZ());
	}

	private void dropItemsAt(String where, Map<String, Integer> items) {
		int entities = 0;

		for (Map.Entry<String, Integer> en : items.entrySet()) {
			if (!ITEM_SPEC.matcher(en.getKey()).matches()) {
				continue;
			}

			int max = Math.max(1, stackOf(en.getKey()).getMaxStackSize());
			int left = en.getValue();

			while (left > 0 && entities < 200) {
				int n = Math.min(left, max);
				command(where + "summon minecraft:item ~ ~0.6 ~ {Item:{id:\"" + en.getKey()
						+ "\",count:" + n + "},PickupDelay:40}");
				left -= n;
				entities++;
			}
		}
	}

	private void onDeath(Entity body) {
		Map<String, Integer> items = new TreeMap<>(inventory);
		inventory.clear();
		path = null;
		followName = null;
		jumpTick = -1;
		lastHealth = -1f;
		heldItem = "";
		worn.clear();
		sleeping = false;
		bedPos = null;
		food = 20;
		saturation = 5f;
		exhaustion = 0f;
		blocking = false;
		flyTarget = null;

		ServerLevel level = (ServerLevel) body.level();
		boolean keep = level.getGameRules().get(GameRules.KEEP_INVENTORY);
		ServerPlayer nearest = null;
		double best = Double.MAX_VALUE;

		for (ServerPlayer p : server.getPlayerList().getPlayers()) {
			if (p.level() == level && p.distanceTo(body) < best) {
				best = p.distanceTo(body);
				nearest = p;
			}
		}

		if (items.isEmpty()) {
			simpleEvent("dood", "Ik ben doodgegaan. Ik had geen spullen bij me. Gebruik 'roep' om terug te komen.");
			say("Au! Ik ben dood. Roep me maar opnieuw.");
		} else if (keep && nearest != null && boxPhase < 0) {
			// keepInventory staat aan: een oranje doos brengt alles naar de speler
			Entity old = findByUuid(BOX_UUID);

			if (old != null) {
				old.discard();
			}

			boxItems.clear();
			boxItems.putAll(items);
			boxPlayer = nearest.getName().getString();
			boxPhase = 0;
			boxTicks = 0;
			command(at(body) + "summon minecraft:block_display ~-0.5 ~1 ~-0.5 {" + uuidNbt(BOX_UUID)
					+ ",block_state:{Name:\"minecraft:orange_shulker_box\"},teleport_duration:2}");
			simpleEvent("dood", "Ik ben doodgegaan. Een oranje doos brengt mijn spullen naar " + boxPlayer + ". Gebruik 'roep' om terug te komen.");
			say("Au! Ik ben dood. Mijn oranje doos brengt mijn spullen naar " + boxPlayer + ".");
		} else {
			dropItemsAt(at(body), items);
			simpleEvent("dood", "Ik ben doodgegaan. Mijn spullen liggen op de grond waar ik doodging. Gebruik 'roep' om terug te komen.");
			say("Au! Ik ben dood. Mijn spullen liggen op de grond.");
		}
	}

	/** De oranje doos vliegt naar de speler, gaat open en geeft alles. */
	private void boxStep() {
		Entity box = findByUuid(BOX_UUID);
		ServerPlayer p = boxPlayer == null ? null : server.getPlayerList().getPlayerByName(boxPlayer);
		boxTicks++;

		if (boxPhase > 0) {
			boxPhase++;

			if (boxPhase > 30) {
				if (box != null) {
					command(at(box) + "playsound minecraft:block.shulker_box.close block @a ~ ~ ~ 1 1");
					box.discard();
				}

				boxPhase = -1;
			}

			return;
		}

		if (p == null) {
			// speler is weg: spullen blijven liggen waar de doos is (of gaan terug in mijn inventaris)
			if (box != null) {
				dropItemsAt(at(box), boxItems);
				box.discard();
			} else {
				for (Map.Entry<String, Integer> en : boxItems.entrySet()) {
					inventory.merge(en.getKey(), en.getValue(), Integer::sum);
				}
			}

			boxItems.clear();
			boxPhase = -1;
			return;
		}

		boolean arrived = box == null || box.level() != p.level() || boxTicks > 600;

		if (!arrived) {
			double tx = p.getX();
			double ty = p.getY() + 1.0;
			double tz = p.getZ();
			double x = box.getX() + 0.5;
			double y = box.getY();
			double z = box.getZ() + 0.5;
			double dx = tx - x;
			double dy = ty - y;
			double dz = tz - z;
			double d = Math.sqrt(dx * dx + dy * dy + dz * dz);

			if (d > 1.4) {
				double step = Math.min(0.4, d);
				box.setPos(x + dx / d * step - 0.5, y + dy / d * step, z + dz / d * step - 0.5);
				return;
			}
		}

		// aangekomen: open en alles geven
		if (box != null) {
			command(at(box) + "playsound minecraft:block.shulker_box.open block @a ~ ~ ~ 1 1");
			command(at(box) + "particle minecraft:end_rod ~0.5 ~0.8 ~0.5 0.3 0.3 0.3 0.05 30");
		}

		for (Map.Entry<String, Integer> en : boxItems.entrySet()) {
			if (ITEM_SPEC.matcher(en.getKey()).matches() && PLAYER_NAME.matcher(boxPlayer).matches()) {
				command("give " + boxPlayer + " " + en.getKey() + " " + en.getValue());
			}
		}

		say("Mijn doos is open: al mijn spullen zitten nu bij " + boxPlayer + ".");
		simpleEvent("doos", "De oranje doos heeft mijn spullen aan " + boxPlayer + " gegeven.");
		boxItems.clear();
		boxPhase = 1;
	}

	/** Trek automatisch het beste harnas uit mijn inventaris aan (en uit als ik het niet meer heb). */
	private void wearBestArmor() {
		// een schild draag ik vanzelf in mijn andere hand
		boolean hasShield = inventory.containsKey("minecraft:shield");

		if (hasShield != "minecraft:shield".equals(worn.getOrDefault("weapon.offhand", ""))) {
			worn.put("weapon.offhand", hasShield ? "minecraft:shield" : "");
			command("item replace entity " + BOT_UUID + " weapon.offhand with " + (hasShield ? "minecraft:shield" : "minecraft:air"));

			if (hasShield) {
				simpleEvent("harnas", "Ik houd mijn schild vast in mijn andere hand.");
			}
		}

		for (String[] slot : ARMOR_SLOTS) {
			String best = "";
			int bestTier = 0;

			for (String id : inventory.keySet()) {
				if (id.endsWith(slot[1]) && tier(id) > bestTier) {
					best = id;
					bestTier = tier(id);
				}
			}

			String now = worn.getOrDefault(slot[0], "");

			if (!best.equals(now)) {
				worn.put(slot[0], best);

				if (best.isEmpty()) {
					command("item replace entity " + BOT_UUID + " " + slot[0] + " with minecraft:air");
				} else if (ITEM_SPEC.matcher(best).matches()) {
					command("item replace entity " + BOT_UUID + " " + slot[0] + " with " + best);
					simpleEvent("harnas", "Ik heb " + best + " aangetrokken.");
				}
			}
		}
	}

	private static boolean isBed(BlockState state) {
		return blockId(state).endsWith("_bed");
	}

	/** Let op of een speler gaat slapen of wakker wordt. */
	private void watchSleep(Entity bot, ServerLevel level) {
		boolean anySleeping = false;

		for (ServerPlayer p : server.getPlayerList().getPlayers()) {
			if (p.isSleeping()) {
				anySleeping = true;
			}
		}

		if (anySleeping && !playerWasSleeping) {
			simpleEvent("speler_slaapt", "De speler ligt in bed. Gebruik 'slaap' om ook te gaan slapen.");
		}

		if (!anySleeping && playerWasSleeping && sleeping) {
			wake(bot, level, true);
		}

		playerWasSleeping = anySleeping;
	}

	private JsonObject sleep(Entity bot, ServerLevel level) {
		if (sleeping) {
			return msg("Ik slaap al. Zzz.");
		}

		BlockPos c = bot.blockPosition();
		BlockPos bed = null;
		double best = Double.MAX_VALUE;

		for (int x = -5; x <= 5; x++) {
			for (int y = -2; y <= 2; y++) {
				for (int z = -5; z <= 5; z++) {
					BlockPos p = new BlockPos(c.getX() + x, c.getY() + y, c.getZ() + z);
					BlockState state = level.getBlockState(p);

					if (!isBed(state) || !state.toString().contains("part=head") || state.toString().contains("occupied=true")) {
						continue;
					}

					// het oranje bed is van mij: dat kies ik als het er is
					double d = x * x + y * y + z * z - (blockId(state).contains("orange") ? 1000 : 0);

					if (d < best) {
						best = d;
						bed = p;
					}
				}
			}
		}

		if (bed == null) {
			throw new IllegalArgumentException("Ik zie geen vrij bed binnen 5 blokken. Loop eerst naar een bed.");
		}

		// waar ligt het voeteneind? dan weet ik hoe ik moet liggen
		String id = blockId(level.getBlockState(bed));
		int[][] dirs = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}};
		float yaw = 0;

		for (int[] d : dirs) {
			BlockState other = level.getBlockState(new BlockPos(bed.getX() + d[0], bed.getY(), bed.getZ() + d[1]));

			if (blockId(other).equals(id) && other.toString().contains("part=foot")) {
				yaw = (float) Math.toDegrees(Math.atan2(d[0], -d[1]));
			}
		}

		path = null;
		flyTarget = null;
		followName = null;
		jumpTick = -1;
		bedPos = new int[] {bed.getX(), bed.getY(), bed.getZ()};
		bot.setDeltaMovement(Vec3.ZERO);
		bot.setPos(bed.getX() + 0.5, bed.getY() + 0.6875, bed.getZ() + 0.5);

		if (bot instanceof LivingEntity living) {
			// zo weet Minecraft in welk bed ik lig en tekent het me recht op het matras (hoofd op het kussen)
			living.setSleepingPos(bed);
		}
		bot.setYRot(yaw);
		bot.setYHeadRot(yaw);
		bot.setYBodyRot(yaw);
		bot.setXRot(0);
		command("data merge entity " + BOT_UUID + " {pose:\"sleeping\",NoGravity:1b}");
		sleeping = true;
		return msg("Ik lig in bed (" + id + "). Welterusten! Ik word wakker als de speler opstaat, of met 'word_wakker'.");
	}

	private void wake(Entity bot, ServerLevel level, boolean morning) {
		if (!sleeping) {
			return;
		}

		sleeping = false;

		if (bot instanceof LivingEntity living) {
			living.clearSleepingPos();
		}

		command("data merge entity " + BOT_UUID + " {pose:\"standing\",NoGravity:" + (creative ? 1 : 0) + "b}");

		if (bedPos != null) {
			int[] safe = safeSpot(level, bedPos[0], bedPos[1], bedPos[2]);

			if (safe != null) {
				bot.setPos(safe[0] + 0.5, safe[1], safe[2] + 0.5);
			}
		}

		bedPos = null;
		simpleEvent("wakker", morning ? "De speler is opgestaan, ik ben ook wakker." : "Ik ben wakker.");

		if (morning) {
			say("Goedemorgen!");
		}
	}

	/** Zet een heel bed neer (voeteneind + hoofdeind) met 1 bed uit mijn inventaris. */
	private JsonObject placeBed(Entity bot, ServerLevel level, int x, int y, int z, String id) {
		if (!infiniteBlocks && inventory.getOrDefault(id, 0) < 1) {
			throw new IllegalArgumentException("Ik heb geen " + id + " in mijn inventaris.");
		}

		String[] names = {"north", "east", "south", "west"};
		int[][] dirs = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}};
		BlockPos feet = bot.blockPosition();

		for (int k = 0; k < 4; k++) {
			BlockPos head = new BlockPos(x + dirs[k][0], y, z + dirs[k][1]);

			if (!level.getBlockState(head).isAir() || head.equals(feet) || head.equals(feet.above())
					|| PathFinder.kindOf(level, head.below()) != 1) {
				continue;
			}

			lookAt(bot, x + 0.5, y + 0.5, z + 0.5);
			commandAsBot("setblock " + head.getX() + " " + y + " " + head.getZ() + " " + id + "[part=head,facing=" + names[k] + "] replace");
			commandAsBot("setblock " + x + " " + y + " " + z + " " + id + "[part=foot,facing=" + names[k] + "] replace");

			if (!isBed(level.getBlockState(new BlockPos(x, y, z)))) {
				throw new IllegalArgumentException("Het bed neerzetten is niet gelukt.");
			}

			if (!infiniteBlocks) {
				take(id, 1);
			}

			return msg("Bed neergezet: voeteneind op " + x + " " + y + " " + z + ", hoofdeind naar het " + names[k] + ".");
		}

		throw new IllegalArgumentException("Naast die plek is geen vrije ruimte voor de andere helft van het bed.");
	}

	/**
	 * Zit mijn HOOFD echt in een vast blok (dan stik ik)? Dan omhoog naar de eerste vrije plek.
	 * Staan op een kist, bed, honing of half blok telt niet: daar zit alleen mijn voet "in" het blok.
	 * Pas na 3 keer achter elkaar (driekwart seconde) en daarna minstens 5 seconden rust.
	 */
	private void unstuck(Entity bot, ServerLevel level) {
		Vec3 eye = bot.getEyePosition();
		BlockPos head = new BlockPos((int) Math.floor(eye.x), (int) Math.floor(eye.y), (int) Math.floor(eye.z));

		if (PathFinder.kindOf(level, head) != 1) {
			stuckChecks = 0;
			return;
		}

		stuckChecks++;
		int tick = server.getTickCount();

		if (stuckChecks < 3 || tick - lastUnstuckTick < 100) {
			return;
		}

		BlockPos feet = bot.blockPosition();

		for (int up = 1; up <= 24; up++) {
			if (PathFinder.canStand(level, feet.getX(), feet.getY() + up, feet.getZ())) {
				bot.setPos(feet.getX() + 0.5, feet.getY() + up, feet.getZ() + 0.5);
				path = null;
				stuckChecks = 0;
				lastUnstuckTick = tick;
				simpleEvent("losgekomen", "Mijn hoofd zat in een blok. Ik ben omhoog gegaan naar een vrije plek.");
				return;
			}
		}

		lastUnstuckTick = tick;
	}

	/** Zoekt bij een doel de dichtstbijzijnde plek waar ik veilig kan staan. */
	private int[] safeSpot(ServerLevel level, int x, int y, int z) {
		if (PathFinder.canStand(level, x, y, z)) {
			return new int[] {x, y, z};
		}

		int[] best = null;
		double bestDist = Double.MAX_VALUE;

		for (int dx = -3; dx <= 3; dx++) {
			for (int dy = -4; dy <= 6; dy++) {
				for (int dz = -3; dz <= 3; dz++) {
					double d = dx * dx + dy * dy + dz * dz;

					if (d < bestDist && PathFinder.canStand(level, x + dx, y + dy, z + dz)) {
						bestDist = d;
						best = new int[] {x + dx, y + dy, z + dz};
					}
				}
			}
		}

		return best;
	}

	private void pickUpItems(Entity bot, ServerLevel level) {
		for (Entity e : level.getEntities(bot, bot.getBoundingBox().inflate(1.6))) {
			if (e instanceof ItemEntity item && item.isAlive() && item.tickCount >= 20) {
				ItemStack stack = item.getItem();

				if (!stack.isEmpty()) {
					inventory.merge(BuiltInRegistries.ITEM.getKey(stack.getItem()).toString(), stack.getCount(), Integer::sum);
				}

				item.discard();
			}
		}
	}

	private static boolean isWater(ServerLevel level, BlockPos pos) {
		return level.getBlockState(pos).getFluidState().is(FluidTags.WATER);
	}

	/** Blijf drijven: hoofd boven water, zodat ik niet verdrink. */
	private void floatInWater(Entity bot, ServerLevel level) {
		BlockPos feet = bot.blockPosition();

		if (!isWater(level, feet)) {
			return;
		}

		int top = feet.getY();

		while (top - feet.getY() < 12 && isWater(level, new BlockPos(feet.getX(), top + 1, feet.getZ()))) {
			top++;
		}

		double want = top + 0.35;
		double y = bot.getY();

		if (Math.abs(want - y) > 0.02) {
			double step = Math.max(-0.15, Math.min(0.15, want - y));
			bot.setPos(bot.getX(), y + step, bot.getZ());
		}
	}

	private void jumpStep(Entity bot) {
		if (jumpTick >= JUMP_CURVE.length) {
			bot.setPos(bot.getX(), jumpBaseY, bot.getZ());
			jumpTick = -1;
			return;
		}

		bot.setPos(bot.getX(), jumpBaseY + JUMP_CURVE[jumpTick], bot.getZ());
		jumpTick++;
	}

	/** Doet een dichte houten deur open (boven- en onderkant). */
	private void openDoor(ServerLevel level, BlockPos pos) {
		for (BlockPos p : new BlockPos[] {pos, pos.above()}) {
			BlockState state = level.getBlockState(p);

			if (PathFinder.isWoodenDoor(state) && state.hasProperty(BlockStateProperties.OPEN)
					&& !state.getValue(BlockStateProperties.OPEN)) {
				level.setBlock(p, state.setValue(BlockStateProperties.OPEN, true), 10);
			}
		}
	}

	private void equip(String itemId) {
		if (itemId == null || itemId.equals(heldItem)) {
			return;
		}

		heldItem = itemId;

		if (itemId.isEmpty()) {
			command("item replace entity " + BOT_UUID + " weapon.mainhand with minecraft:air");
		} else if (ITEM_SPEC.matcher(itemId).matches()) {
			command("item replace entity " + BOT_UUID + " weapon.mainhand with " + itemId);
		}
	}

	private static ItemStack stackOf(String itemId) {
		return new ItemStack(BuiltInRegistries.ITEM.getValue(Identifier.parse(itemId)));
	}

	private static int tier(String id) {
		if (id.contains("netherite")) return 6;
		if (id.contains("diamond")) return 5;
		if (id.contains("iron")) return 4;
		if (id.contains("stone") || id.contains("copper") || id.contains("chainmail")) return 3;
		if (id.contains("golden")) return 2;
		return 1;
	}

	/** Het beste gereedschap uit mijn inventaris voor dit blok ("" = met de hand). */
	private String bestTool(BlockState state) {
		String best = "";
		int bestTier = 0;

		for (String id : inventory.keySet()) {
			boolean isTool = id.endsWith("_pickaxe") || id.endsWith("_axe") || id.endsWith("_shovel")
					|| id.endsWith("_hoe") || id.endsWith("shears") || id.endsWith("_sword");

			if (isTool && tier(id) > bestTier && stackOf(id).isCorrectToolForDrops(state)) {
				best = id;
				bestTier = tier(id);
			}
		}

		return best;
	}

	private String bestWeapon() {
		String best = "";
		int bestTier = 0;

		for (String id : inventory.keySet()) {
			if ((id.endsWith("_sword") || id.endsWith("_axe")) && tier(id) > bestTier) {
				best = id;
				bestTier = tier(id);
			}
		}

		return best;
	}

	private int attackDamage() {
		String weapon = bestWeapon();
		equip(weapon);
		return weapon.isEmpty() ? 2 : 3 + tier(weapon);
	}

	/** Zoekt een pad en begint te lopen. Geeft null terug als er helemaal geen stap te zetten is. */
	private PathFinder.Result startPath(Entity bot, ServerLevel level, int gx, int gy, int gz, double tolerance) {
		BlockPos start = bot.blockPosition();
		PathFinder.Result result = PathFinder.find(level, start.getX(), start.getY(), start.getZ(), gx, gy, gz, tolerance);

		if (result.nodes.size() < 2) {
			if (result.complete) {
				path = null;
				return result;
			}

			return null;
		}

		path = result.nodes;
		pathIndex = 1;
		goalX = gx;
		goalY = gy;
		goalZ = gz;
		goalTolerance = tolerance;
		return result;
	}

	private void followStep(Entity bot, ServerLevel level) {
		ServerPlayer p = server.getPlayerList().getPlayerByName(followName);

		if (p == null) {
			return;
		}

		boolean sameLevel = p.level() == bot.level();
		double d = sameLevel ? p.distanceTo(bot) : 1.0e9;

		if (!sameLevel || d > 48 || (followFails >= 3 && d > 8)) {
			command("tp " + BOT_UUID + " " + followName);
			path = null;
			followFails = 0;
			return;
		}

		if (d <= 4.0) {
			return;
		}

		BlockPos pp = p.blockPosition();
		boolean goalStillClose = path != null
				&& Math.abs(goalX - pp.getX()) + Math.abs(goalY - pp.getY()) + Math.abs(goalZ - pp.getZ()) <= 3;

		if (goalStillClose) {
			return;
		}

		repaths = 0;
		PathFinder.Result result = startPath(bot, level, pp.getX(), pp.getY(), pp.getZ(), 2.5);

		if (result == null || !result.complete) {
			followFails++;
		} else {
			followFails = 0;
		}
	}

	private void idleLook(Entity bot, ServerLevel level) {
		ServerPlayer nearest = null;
		double best = 10.0;

		for (ServerPlayer p : server.getPlayerList().getPlayers()) {
			if (p.level() == level) {
				double d = p.distanceTo(bot);

				if (d < best) {
					best = d;
					nearest = p;
				}
			}
		}

		if (nearest != null) {
			Vec3 eye = nearest.getEyePosition();
			lookAt(bot, eye.x, eye.y, eye.z);
		}
	}

	private List<Entity> hostiles(Entity bot, ServerLevel level) {
		List<Entity> result = new ArrayList<>();

		for (Entity e : level.getEntities(bot, bot.getBoundingBox().inflate(DANGER_RANGE))) {
			if (e instanceof Enemy && e.isAlive()) {
				result.add(e);
			}
		}

		result.sort(Comparator.comparingDouble(e -> e.distanceTo(bot)));
		return result;
	}

	private void dangerScan(Entity bot, ServerLevel level, int tick) {
		List<Entity> threats = hostiles(bot, level);
		Set<UUID> now = new HashSet<>();

		for (Entity e : threats) {
			now.add(e.getUUID());

			if (knownThreats.add(e.getUUID())) {
				JsonObject ev = new JsonObject();
				ev.addProperty("type", "gevaar");
				ev.addProperty("wat", e.getName().getString());
				ev.addProperty("afstand", r1(e.distanceTo(bot)));
				ev.addProperty("richting", direction(e.getX() - bot.getX(), e.getZ() - bot.getZ()));
				ev.add("pos", posArray(e.getX(), e.getY(), e.getZ()));
				event(ev);
			}
		}

		knownThreats.retainAll(now);

		if (threats.isEmpty()) {
			return;
		}

		Entity nearest = threats.get(0);
		double d = nearest.distanceTo(bot);

		if (warnInChat && d <= 10.0 && tick - lastWarnTick > 300) {
			lastWarnTick = tick;
			say("Pas op! " + nearest.getName().getString() + " op " + Math.round(d) + " blokken, "
					+ direction(nearest.getX() - bot.getX(), nearest.getZ() - bot.getZ()) + " van mij.");
		}

		if (defend && d <= 3.5 && tick - lastAttackTick >= 12) {
			lastAttackTick = tick;
			lookAt(bot, nearest.getX(), nearest.getEyePosition().y, nearest.getZ());
			command("damage " + nearest.getUUID() + " " + attackDamage() + " minecraft:mob_attack by " + BOT_UUID);
		}
	}

	// ------------------------------------------------------------------
	// opdrachten vanaf de MCP server
	// ------------------------------------------------------------------

	public JsonObject handle(String cmd, JsonObject req) {
		JsonObject res;

		try {
			res = run(cmd, req);

			if (!res.has("ok")) {
				res.addProperty("ok", true);
			}
		} catch (IllegalArgumentException e) {
			res = new JsonObject();
			res.addProperty("ok", false);
			res.addProperty("fout", e.getMessage());
		} catch (Throwable t) {
			ClaudeBuddy.LOGGER.error("Claude Buddy opdracht '{}' ging mis", cmd, t);
			res = new JsonObject();
			res.addProperty("ok", false);
			res.addProperty("fout", "Interne fout: " + t);
		}

		// gevaar zit ALTIJD in het antwoord, zodat Claude het nooit mist
		if (!cmd.equals("status")) {
			Entity bot = find();

			if (bot != null) {
				JsonArray danger = dangerJson(bot, (ServerLevel) bot.level(), 6);

				if (!danger.isEmpty()) {
					res.add("gevaar", danger);
				}
			}
		}

		res.addProperty("wachtende_gebeurtenissen", events.size());
		return res;
	}

	private Entity need() {
		Entity bot = find();

		if (bot == null) {
			throw new IllegalArgumentException("Claude staat nog niet in de wereld (of in een stuk dat niet geladen is). Gebruik eerst 'roep'.");
		}

		return bot;
	}

	private JsonObject run(String cmd, JsonObject req) {
		switch (cmd) {
		case "status":
			return status();
		case "events":
			return drainEvents();
		case "roep": {
			Entity sitting = find();

			if (sitting != null && sitting.isPassenger()) {
				command("ride " + BOT_UUID + " dismount");
			}

			return summon(s(req, "speler", ""));
		}
		case "verwijder": {
			Entity old = find();

			if (old != null) {
				old.discard();
			}

			path = null;
			followName = null;
			return msg("Claude is uit de wereld gehaald.");
		}
		case "zeg":
			say(s(req, "tekst", ""));
			return new JsonObject();
		case "instelling":
			return setting(req);
		default:
			break;
		}

		Entity bot = need();
		ServerLevel level = (ServerLevel) bot.level();

		if (bot.isPassenger() && (cmd.equals("loop") || cmd.equals("loop_speler") || cmd.equals("volg") || cmd.equals("tp")
				|| cmd.equals("spring") || cmd.equals("slaap"))) {
			command("ride " + BOT_UUID + " dismount");
		}

		if (cmd.equals("slaap")) {
			return sleep(bot, level);
		}

		if (cmd.equals("word_wakker")) {
			if (!sleeping) {
				return msg("Ik was al wakker.");
			}

			wake(bot, level, false);
			return msg("Ik ben wakker en sta naast het bed.");
		}

		boolean looking = cmd.equals("scan") || cmd.equals("blok") || cmd.equals("gebied") || cmd.equals("recepten")
				|| cmd.startsWith("kijk_naar");

		if (sleeping && !looking) {
			wake(bot, level, false);
		}

		switch (cmd) {
		case "scan":
			return scan(bot, level, req);
		case "blok":
			return blockAt(level, i(req, "x"), i(req, "y"), i(req, "z"));
		case "gebied":
			return area(level, req);
		case "loop":
			followName = null;

			if (creative) {
				return fly(bot, i(req, "x"), i(req, "y"), i(req, "z"));
			}

			return walk(bot, level, i(req, "x"), i(req, "y"), i(req, "z"), 1.5);
		case "loop_speler": {
			followName = null;
			ServerPlayer p = playerOrNearest(bot, s(req, "speler", ""));

			if (p.level() != level) {
				throw new IllegalArgumentException(p.getName().getString() + " is in een andere dimensie. Gebruik 'roep' om erheen te teleporteren.");
			}

			BlockPos pp = p.blockPosition();
			return walk(bot, level, pp.getX(), pp.getY(), pp.getZ(), 2.5);
		}
		case "volg": {
			ServerPlayer p = playerOrNearest(bot, s(req, "speler", ""));
			followName = p.getName().getString();
			followFails = 0;
			return msg("Ik volg nu " + followName + ".");
		}
		case "stop":
			path = null;
			flyTarget = null;
			followName = null;
			return msg("Gestopt.");
		case "tp": {
			int[] safe = safeSpot(level, i(req, "x"), i(req, "y"), i(req, "z"));

			if (safe == null) {
				throw new IllegalArgumentException("Daar is geen veilige plek om te staan (vol met blokken, of te ver weg). Ik teleporteer niet, anders stik ik.");
			}

			path = null;
			flyTarget = null;
			commandAsBot(String.format(Locale.ROOT, "tp @s %.2f %.2f %.2f", safe[0] + 0.5, (double) safe[1], safe[2] + 0.5));
			JsonObject o = msg("Geteleporteerd naar een veilige plek: " + safe[0] + " " + safe[1] + " " + safe[2] + ".");
			o.add("pos", posArray(safe[0], safe[1], safe[2]));
			return o;
		}
		case "kijk_naar":
		case "kijk_naar_voor_foto":
			return look(bot, level, req);
		case "hak":
			return dig(bot, level, i(req, "x"), i(req, "y"), i(req, "z"));
		case "hak_gebied":
			return digArea(bot, level, req);
		case "plaats":
			return place(bot, level, i(req, "x"), i(req, "y"), i(req, "z"), s(req, "blok", ""));
		case "vul":
			return fill(bot, req);
		case "val_aan":
			return attack(bot, level, s(req, "soort", ""));
		case "spring":
			return jump(bot, level);
		case "gebruik":
			return use(bot, level, i(req, "x"), i(req, "y"), i(req, "z"));
		case "maak":
			return craft(bot, level, s(req, "item", ""), req.has("aantal") ? Math.max(1, i(req, "aantal")) : 1);
		case "recepten":
			return recipeList();
		case "rijd":
			return ride(bot, level, s(req, "soort", ""));
		case "stap_af":
			return dismount(bot);
		case "schild":
			return shieldUp(req.has("omhoog") && req.get("omhoog").getAsBoolean());
		case "gebruik_item":
			return useItemOn(bot, level, s(req, "item", ""), i(req, "x"), i(req, "y"), i(req, "z"));
		case "gebruik_dier":
			return useItemOnEntity(bot, level, s(req, "item", ""), s(req, "soort", ""));
		case "drink":
			return drink(bot, level, s(req, "item", ""));
		case "eet":
			return eat(bot, level, s(req, "item", ""));
		case "kist":
			return chest(bot, level, req);
		case "geef":
			return give(bot, req);
		default:
			throw new IllegalArgumentException("Onbekende opdracht: " + cmd);
		}
	}

	private static JsonObject msg(String text) {
		JsonObject o = new JsonObject();
		o.addProperty("bericht", text);
		return o;
	}

	private JsonObject drainEvents() {
		JsonObject o = new JsonObject();
		JsonArray list = new JsonArray();
		JsonObject e;

		while (list.size() < 50 && (e = events.pollFirst()) != null) {
			list.add(e);
		}

		o.add("gebeurtenissen", list);
		return o;
	}

	private JsonObject setting(JsonObject req) {
		String name = s(req, "naam", "");
		boolean value = req.has("waarde") && req.get("waarde").getAsBoolean();

		switch (name) {
		case "oneindig_blokken":
			infiniteBlocks = value;
			break;
		case "verdedigen":
			defend = value;
			break;
		case "spelers_slaan":
			hitPlayers = value;
			break;
		case "waarschuwen":
			warnInChat = value;
			break;
		case "rennen":
			speed = value ? 0.28 : 0.22;
			break;
		case "creatief":
			return msg(gameMode(value ? "c" : "s"));
		case "zelf_eten":
			autoEat = value;
			break;
		default:
			throw new IllegalArgumentException("Onbekende instelling. Kies: oneindig_blokken, verdedigen, waarschuwen, rennen, creatief, spelers_slaan, zelf_eten.");
		}

		return msg(name + " = " + value);
	}

	// ---------------- sensoren ----------------

	private JsonArray dangerJson(Entity bot, ServerLevel level, int max) {
		JsonArray a = new JsonArray();

		for (Entity e : hostiles(bot, level)) {
			if (a.size() >= max) {
				break;
			}

			JsonObject o = new JsonObject();
			o.addProperty("wat", e.getName().getString());
			o.addProperty("afstand", r1(e.distanceTo(bot)));
			o.addProperty("richting", direction(e.getX() - bot.getX(), e.getZ() - bot.getZ()));
			o.add("pos", posArray(e.getX(), e.getY(), e.getZ()));

			if (e instanceof LivingEntity living) {
				o.addProperty("levens", r1(living.getHealth()));
			}

			a.add(o);
		}

		return a;
	}

	private JsonObject status() {
		JsonObject o = new JsonObject();
		Entity bot = find();

		JsonArray players = new JsonArray();

		for (ServerPlayer p : server.getPlayerList().getPlayers()) {
			JsonObject pj = new JsonObject();
			pj.addProperty("naam", p.getName().getString());
			pj.add("pos", posArray(p.getX(), p.getY(), p.getZ()));
			pj.addProperty("levens", r1(p.getHealth()));

			ItemStack hand = p.getMainHandItem();

			if (!hand.isEmpty()) {
				pj.addProperty("in_hand", BuiltInRegistries.ITEM.getKey(hand.getItem()).toString() + " x" + hand.getCount());
			}

			if (bot != null && p.level() == bot.level()) {
				pj.addProperty("afstand", r1(p.distanceTo(bot)));
				pj.addProperty("richting", direction(p.getX() - bot.getX(), p.getZ() - bot.getZ()));
			} else if (bot != null) {
				pj.addProperty("andere_dimensie", true);
			}

			// waar kijkt de speler naar?
			ServerLevel pl = (ServerLevel) p.level();
			Vec3 eye = p.getEyePosition();
			Vec3 look = p.getLookAngle();

			for (double d = 0.5; d <= 8.0; d += 0.1) {
				BlockPos bp = new BlockPos((int) Math.floor(eye.x + look.x * d), (int) Math.floor(eye.y + look.y * d),
						(int) Math.floor(eye.z + look.z * d));
				BlockState state = pl.getBlockState(bp);

				if (!state.isAir()) {
					JsonObject lookJson = new JsonObject();
					lookJson.addProperty("blok", blockId(state));
					lookJson.add("pos", posArray(bp.getX(), bp.getY(), bp.getZ()));
					pj.add("kijkt_naar", lookJson);
					break;
				}
			}

			players.add(pj);
		}

		o.add("spelers", players);

		if (bot == null) {
			o.addProperty("claude_in_wereld", false);
			o.addProperty("tip", "Gebruik 'roep' om Claude bij een speler te laten verschijnen.");
			return o;
		}

		ServerLevel level = (ServerLevel) bot.level();
		BlockPos bp = bot.blockPosition();
		o.addProperty("claude_in_wereld", true);
		o.add("pos", posArray(bot.getX(), bot.getY(), bot.getZ()));
		o.add("blokpos", posArray(bp.getX(), bp.getY(), bp.getZ()));
		o.addProperty("dimensie", level.dimension().identifier().toString());
		o.addProperty("staat_op", blockId(level.getBlockState(bp.below())));

		if (bot instanceof LivingEntity living) {
			o.addProperty("levens", r1(living.getHealth()));
		}

		o.addProperty("in_water", isWater(level, bp));
		o.addProperty("in_hand", heldItem.isEmpty() ? "niks" : heldItem);
		o.addProperty("slaapt", sleeping);

		JsonObject armor = new JsonObject();

		for (String[] slot : ARMOR_SLOTS) {
			String item = worn.getOrDefault(slot[0], "");

			if (!item.isEmpty()) {
				armor.addProperty(slot[2], item);
			}
		}

		o.add("harnas_aan", armor);
		o.addProperty("licht", level.getMaxLocalRawBrightness(bp));
		o.addProperty("regen", level.isRaining());
		o.addProperty("bezig", sleeping ? "slapen" : path != null || flyTarget != null ? "lopen" : followName != null ? "volgen" : "stilstaan");

		if (followName != null) {
			o.addProperty("volgt", followName);
		}

		o.add("gevaar", dangerJson(bot, level, 10));

		// andere wezens (dieren, dorpelingen, items) in de buurt, geteld per soort
		Map<String, Integer> counts = new TreeMap<>();
		Map<String, Entity> nearestOf = new HashMap<>();

		for (Entity e : level.getEntities(bot, bot.getBoundingBox().inflate(DANGER_RANGE))) {
			if (e instanceof Enemy || e instanceof ServerPlayer || !e.isAlive()) {
				continue;
			}

			String id = entityId(e);
			counts.merge(id, 1, Integer::sum);
			Entity old = nearestOf.get(id);

			if (old == null || e.distanceTo(bot) < old.distanceTo(bot)) {
				nearestOf.put(id, e);
			}
		}

		JsonArray others = new JsonArray();

		for (Map.Entry<String, Integer> en : counts.entrySet()) {
			Entity e = nearestOf.get(en.getKey());
			JsonObject ej = new JsonObject();
			ej.addProperty("soort", en.getKey());
			ej.addProperty("aantal", en.getValue());
			ej.addProperty("dichtstbij", r1(e.distanceTo(bot)));
			ej.addProperty("richting", direction(e.getX() - bot.getX(), e.getZ() - bot.getZ()));
			others.add(ej);
		}

		o.add("wezens", others);

		JsonObject inv = new JsonObject();

		for (Map.Entry<String, Integer> en : inventory.entrySet()) {
			inv.addProperty(en.getKey(), en.getValue());
		}

		o.add("inventaris", inv);

		JsonObject settings = new JsonObject();
		settings.addProperty("oneindig_blokken", infiniteBlocks);
		settings.addProperty("creatief", creative);
		settings.addProperty("verdedigen", defend);
		settings.addProperty("spelers_slaan", hitPlayers);
		settings.addProperty("waarschuwen", warnInChat);
		settings.addProperty("rennen", speed > 0.25);
		settings.addProperty("zelf_eten", autoEat);
		o.add("instellingen", settings);
		o.addProperty("honger", food);
		o.addProperty("schild_omhoog", blocking);

		Entity me = find();

		if (me != null && me.isPassenger() && me.getVehicle() != null) {
			o.addProperty("zit_op", entityId(me.getVehicle()));
		}

		return o;
	}

	private JsonObject scan(Entity bot, ServerLevel level, JsonObject req) {
		int r = Math.max(1, Math.min(10, req.has("straal") ? i(req, "straal") : 6));
		BlockPos c = bot.blockPosition();
		Map<String, Integer> counts = new TreeMap<>();
		Map<String, int[]> nearest = new HashMap<>();
		Map<String, Double> nearestDist = new HashMap<>();

		for (int x = c.getX() - r; x <= c.getX() + r; x++) {
			for (int y = c.getY() - r; y <= c.getY() + r; y++) {
				for (int z = c.getZ() - r; z <= c.getZ() + r; z++) {
					BlockPos p = new BlockPos(x, y, z);

					if (!level.isLoaded(p)) {
						continue;
					}

					BlockState state = level.getBlockState(p);

					if (state.isAir()) {
						continue;
					}

					String id = blockId(state);
					counts.merge(id, 1, Integer::sum);
					double d = Math.sqrt(Math.pow(x - c.getX(), 2) + Math.pow(y - c.getY(), 2) + Math.pow(z - c.getZ(), 2));
					Double old = nearestDist.get(id);

					if (old == null || d < old) {
						nearestDist.put(id, d);
						nearest.put(id, new int[] {x, y, z});
					}
				}
			}
		}

		JsonObject o = new JsonObject();
		JsonArray blocks = new JsonArray();

		for (Map.Entry<String, Integer> en : counts.entrySet()) {
			int[] n = nearest.get(en.getKey());
			JsonObject b = new JsonObject();
			b.addProperty("blok", en.getKey());
			b.addProperty("aantal", en.getValue());
			b.add("dichtstbij", posArray(n[0], n[1], n[2]));
			blocks.add(b);
		}

		o.addProperty("straal", r);
		o.add("midden", posArray(c.getX(), c.getY(), c.getZ()));
		o.add("blokken", blocks);
		return o;
	}

	private JsonObject blockAt(ServerLevel level, int x, int y, int z) {
		JsonObject o = new JsonObject();
		o.addProperty("blok", blockId(level.getBlockState(new BlockPos(x, y, z))));
		o.add("pos", posArray(x, y, z));
		return o;
	}

	private static int[] box(JsonObject req) {
		int x1 = Math.min(i(req, "x1"), i(req, "x2"));
		int y1 = Math.min(i(req, "y1"), i(req, "y2"));
		int z1 = Math.min(i(req, "z1"), i(req, "z2"));
		int x2 = Math.max(i(req, "x1"), i(req, "x2"));
		int y2 = Math.max(i(req, "y1"), i(req, "y2"));
		int z2 = Math.max(i(req, "z1"), i(req, "z2"));
		return new int[] {x1, y1, z1, x2, y2, z2};
	}

	private static long volume(int[] b) {
		return (long) (b[3] - b[0] + 1) * (b[4] - b[1] + 1) * (b[5] - b[2] + 1);
	}

	private JsonObject area(ServerLevel level, JsonObject req) {
		int[] b = box(req);

		if (volume(b) > 4096) {
			throw new IllegalArgumentException("Gebied te groot (max 4096 blokken).");
		}

		JsonObject o = new JsonObject();
		JsonArray list = new JsonArray();
		int skipped = 0;

		for (int y = b[1]; y <= b[4]; y++) {
			for (int x = b[0]; x <= b[3]; x++) {
				for (int z = b[2]; z <= b[5]; z++) {
					BlockState state = level.getBlockState(new BlockPos(x, y, z));

					if (state.isAir()) {
						continue;
					}

					if (list.size() >= 600) {
						skipped++;
						continue;
					}

					JsonArray entry = new JsonArray();
					entry.add(x);
					entry.add(y);
					entry.add(z);
					entry.add(blockId(state));
					list.add(entry);
				}
			}
		}

		o.add("blokken", list);
		o.addProperty("uitleg", "Elke regel is [x, y, z, blok]. Lucht staat er niet bij.");

		if (skipped > 0) {
			o.addProperty("niet_getoond", skipped);
		}

		return o;
	}

	// ---------------- bewegen ----------------

	private JsonObject walk(Entity bot, ServerLevel level, int x, int y, int z, double tolerance) {
		repaths = 0;
		PathFinder.Result result = startPath(bot, level, x, y, z, tolerance);
		JsonObject o = new JsonObject();

		if (result == null) {
			o.addProperty("ok", false);
			o.addProperty("fout", "Ik kan daar niet heen lopen (geen pad gevonden). Probeer een plek dichterbij, of gebruik teleporteer.");
			return o;
		}

		o.addProperty("stappen", Math.max(0, result.nodes.size() - 1));
		o.addProperty("pad_compleet", result.complete);

		if (!result.complete) {
			int[] end = result.nodes.get(result.nodes.size() - 1);
			o.addProperty("bericht", "Ik kan er niet helemaal komen. Ik loop zo ver als ik kan, tot " + end[0] + " " + end[1] + " " + end[2] + ".");
		} else if (result.nodes.size() < 2) {
			o.addProperty("bericht", "Ik sta er al.");
		} else {
			o.addProperty("bericht", "Ik ben onderweg.");
		}

		return o;
	}

	private JsonObject look(Entity bot, ServerLevel level, JsonObject req) {
		String player = s(req, "speler", "");

		if (!player.isEmpty()) {
			ServerPlayer p = playerOrNearest(bot, player);
			Vec3 eye = p.getEyePosition();
			lookAt(bot, eye.x, eye.y, eye.z);
		} else if (req.has("x") && req.has("y") && req.has("z")) {
			lookAt(bot, i(req, "x") + 0.5, i(req, "y") + 0.5, i(req, "z") + 0.5);
		} else if (req.has("richting")) {
			double yaw;

			switch (s(req, "richting", "")) {
			case "noord":
				yaw = 180;
				break;
			case "oost":
				yaw = -90;
				break;
			case "zuid":
				yaw = 0;
				break;
			case "west":
				yaw = 90;
				break;
			default:
				throw new IllegalArgumentException("Richting moet noord, oost, zuid of west zijn.");
			}

			double pitch = req.has("omhoog") ? -req.get("omhoog").getAsDouble() : 0;
			bot.setYRot((float) yaw);
			bot.setYHeadRot((float) yaw);
			bot.setYBodyRot((float) yaw);
			bot.setXRot((float) Math.max(-89, Math.min(89, pitch)));
		}

		return new JsonObject();
	}

	// ---------------- hakken en bouwen ----------------

	private boolean inReach(Entity bot, int x, int y, int z, double reach) {
		Vec3 eye = bot.getEyePosition();
		double dx = x + 0.5 - eye.x;
		double dy = y + 0.5 - eye.y;
		double dz = z + 0.5 - eye.z;
		return dx * dx + dy * dy + dz * dz <= reach * reach;
	}

	private String breakBlock(Entity bot, ServerLevel level, int x, int y, int z) {
		BlockPos pos = new BlockPos(x, y, z);
		BlockState state = level.getBlockState(pos);

		if (state.isAir()) {
			return null;
		}

		if (state.getDestroySpeed(level, pos) < 0) {
			return null;
		}

		String id = blockId(state);
		String tool = bestTool(state);
		equip(tool);

		// echte Minecraft-drops: zonder de goede houweel krijg je bijvoorbeeld geen steen
		BlockEntity blockEntity = level.getBlockEntity(pos);
		Block.dropResources(state, level, pos, blockEntity, bot, tool.isEmpty() ? ItemStack.EMPTY : stackOf(tool));
		level.destroyBlock(pos, false, (Entity) null);
		return id;
	}

	private JsonObject dig(Entity bot, ServerLevel level, int x, int y, int z) {
		if (!inReach(bot, x, y, z, REACH)) {
			throw new IllegalArgumentException("Dat blok is te ver weg om te hakken. Loop er eerst naartoe (max " + REACH + " blokken).");
		}

		lookAt(bot, x + 0.5, y + 0.5, z + 0.5);
		String id = breakBlock(bot, level, x, y, z);

		if (id == null) {
			throw new IllegalArgumentException("Daar valt niks te hakken (lucht of onbreekbaar).");
		}

		exhaust(0.01f);
		JsonObject o = msg("Gehakt: " + id + ". Wat eruit valt pak ik op als ik er vlakbij sta.");
		o.addProperty("blok", id);
		return o;
	}

	private JsonObject digArea(Entity bot, ServerLevel level, JsonObject req) {
		int[] b = box(req);

		if (volume(b) > 125) {
			throw new IllegalArgumentException("Te veel in een keer (max 125 blokken, bijvoorbeeld 5x5x5).");
		}

		Map<String, Integer> broken = new TreeMap<>();
		int tooFar = 0;

		// van boven naar beneden, dan valt er niks op mijn hoofd
		for (int y = b[4]; y >= b[1]; y--) {
			for (int x = b[0]; x <= b[3]; x++) {
				for (int z = b[2]; z <= b[5]; z++) {
					if (!inReach(bot, x, y, z, REACH + 1.0)) {
						if (!level.getBlockState(new BlockPos(x, y, z)).isAir()) {
							tooFar++;
						}

						continue;
					}

					String id = breakBlock(bot, level, x, y, z);

					if (id != null) {
						broken.merge(id, 1, Integer::sum);
					}
				}
			}
		}

		lookAt(bot, (b[0] + b[3]) / 2.0 + 0.5, (b[1] + b[4]) / 2.0 + 0.5, (b[2] + b[5]) / 2.0 + 0.5);
		JsonObject o = new JsonObject();
		JsonObject bj = new JsonObject();

		for (Map.Entry<String, Integer> en : broken.entrySet()) {
			bj.addProperty(en.getKey(), en.getValue());
		}

		o.add("gehakt", bj);

		if (tooFar > 0) {
			o.addProperty("te_ver_weg", tooFar);
			o.addProperty("bericht", "Sommige blokken waren te ver weg. Loop dichterbij en probeer het nog eens.");
		}

		return o;
	}

	private static String normalizeBlock(String spec) {
		String base = spec.contains("[") ? spec.substring(0, spec.indexOf('[')) : spec;
		return base.contains(":") ? base : "minecraft:" + base;
	}

	private static final Map<String, String> ITEM_TO_BLOCK = Map.ofEntries(
			Map.entry("minecraft:redstone", "minecraft:redstone_wire"), Map.entry("minecraft:string", "minecraft:tripwire"),
			Map.entry("minecraft:wheat_seeds", "minecraft:wheat"), Map.entry("minecraft:beetroot_seeds", "minecraft:beetroots"),
			Map.entry("minecraft:melon_seeds", "minecraft:melon_stem"), Map.entry("minecraft:pumpkin_seeds", "minecraft:pumpkin_stem"),
			Map.entry("minecraft:sweet_berries", "minecraft:sweet_berry_bush"), Map.entry("minecraft:cocoa_beans", "minecraft:cocoa"),
			Map.entry("minecraft:glow_berries", "minecraft:cave_vines"));

	private JsonObject place(Entity bot, ServerLevel level, int x, int y, int z, String block) {
		if (!BLOCK_SPEC.matcher(block).matches()) {
			throw new IllegalArgumentException("Raar bloknaam: '" + block + "'. Voorbeeld: minecraft:oak_planks");
		}

		if (!inReach(bot, x, y, z, REACH)) {
			throw new IllegalArgumentException("Die plek is te ver weg om te bouwen. Loop er eerst naartoe (max " + REACH + " blokken).");
		}

		BlockPos pos = new BlockPos(x, y, z);
		BlockState before = level.getBlockState(pos);

		if (!before.isAir() && before.getFluidState().isEmpty()) {
			throw new IllegalArgumentException("Daar staat al een blok: " + blockId(before) + ". Hak het eerst weg.");
		}

		BlockPos feet = bot.blockPosition();

		if (pos.equals(feet) || pos.equals(feet.above())) {
			throw new IllegalArgumentException("Daar sta ik zelf. Ik ga niet in mezelf bouwen.");
		}

		String id = normalizeBlock(block);

		// sommige dingen heten als item anders dan als blok (redstone-poeder, zaadjes)
		if (ITEM_TO_BLOCK.containsKey(id)) {
			block = ITEM_TO_BLOCK.get(id);
		} else {
			for (Map.Entry<String, String> en : ITEM_TO_BLOCK.entrySet()) {
				if (en.getValue().equals(id)) {
					id = en.getKey();
				}
			}
		}

		if (id.endsWith("_bed") && !block.contains("[")) {
			return placeBed(bot, level, x, y, z, id);
		}

		if (!infiniteBlocks && inventory.getOrDefault(id, 0) < 1) {
			throw new IllegalArgumentException("Ik heb geen " + id + " in mijn inventaris.");
		}

		lookAt(bot, x + 0.5, y + 0.5, z + 0.5);
		equip(id);
		commandAsBot("setblock " + x + " " + y + " " + z + " " + block + " replace");

		BlockState after = level.getBlockState(pos);

		if (after.isAir() || after == before) {
			throw new IllegalArgumentException("Plaatsen is niet gelukt. Bestaat het blok '" + block + "' wel?");
		}

		if (!infiniteBlocks) {
			inventory.merge(id, -1, Integer::sum);

			if (inventory.get(id) <= 0) {
				inventory.remove(id);
			}
		}

		return msg("Geplaatst: " + blockId(after));
	}

	private JsonObject fill(Entity bot, JsonObject req) {
		String block = s(req, "blok", "");
		String mode = s(req, "modus", "keep");

		if (!BLOCK_SPEC.matcher(block).matches()) {
			throw new IllegalArgumentException("Raar bloknaam: '" + block + "'.");
		}

		if (!mode.equals("keep") && !mode.equals("replace") && !mode.equals("hollow") && !mode.equals("outline")) {
			throw new IllegalArgumentException("Modus moet keep, replace, hollow of outline zijn.");
		}

		if (!infiniteBlocks) {
			throw new IllegalArgumentException("Vullen kan alleen als 'oneindig_blokken' aan staat. Gebruik anders 'plaats' per blok.");
		}

		int[] b = box(req);

		if (volume(b) > 1000) {
			throw new IllegalArgumentException("Te groot (max 1000 blokken per keer).");
		}

		// dichtstbijzijnde punt van de doos moet binnen 12 blokken zijn
		double cx = Math.max(b[0], Math.min(bot.getX(), b[3] + 1));
		double cy = Math.max(b[1], Math.min(bot.getY(), b[4] + 1));
		double cz = Math.max(b[2], Math.min(bot.getZ(), b[5] + 1));
		double d = Math.sqrt(Math.pow(cx - bot.getX(), 2) + Math.pow(cy - bot.getY(), 2) + Math.pow(cz - bot.getZ(), 2));

		if (d > 12) {
			throw new IllegalArgumentException("Dat is te ver weg om te bouwen. Loop er eerst naartoe (max 12 blokken).");
		}

		BlockPos feet = bot.blockPosition();
		boolean insideMe = feet.getX() >= b[0] && feet.getX() <= b[3] && feet.getZ() >= b[2] && feet.getZ() <= b[5]
				&& feet.getY() + 1 >= b[1] && feet.getY() <= b[4];

		if (insideMe && (mode.equals("keep") || mode.equals("replace"))) {
			throw new IllegalArgumentException("Ik sta zelf in dat gebied. Ik loop eerst opzij, of gebruik modus hollow/outline.");
		}

		lookAt(bot, (b[0] + b[3]) / 2.0 + 0.5, (b[1] + b[4]) / 2.0 + 0.5, (b[2] + b[5]) / 2.0 + 0.5);
		commandAsBot("fill " + b[0] + " " + b[1] + " " + b[2] + " " + b[3] + " " + b[4] + " " + b[5] + " " + block + " " + mode);
		JsonObject o = msg("Gevuld met " + block + " (" + mode + ").");
		o.addProperty("blokken_in_gebied", volume(b));
		return o;
	}

	private JsonObject attack(Entity bot, ServerLevel level, String kind) {
		Entity target = null;

		if (kind.equalsIgnoreCase("speler")) {
			if (!hitPlayers) {
				throw new IllegalArgumentException("Spelers slaan staat uit. Zet eerst de instelling 'spelers_slaan' aan (alleen als de speler erom vraagt).");
			}

			target = playerOrNearest(bot, "");
		} else if (kind.isEmpty()) {
			List<Entity> threats = hostiles(bot, level);

			if (!threats.isEmpty()) {
				target = threats.get(0);
			}
		} else {
			double best = Double.MAX_VALUE;

			for (Entity e : level.getEntities(bot, bot.getBoundingBox().inflate(DANGER_RANGE))) {
				if (e instanceof LivingEntity && !(e instanceof ServerPlayer) && e.isAlive()
						&& entityId(e).contains(kind.toLowerCase(Locale.ROOT)) && e.distanceTo(bot) < best) {
					best = e.distanceTo(bot);
					target = e;
				}
			}
		}

		if (target == null) {
			throw new IllegalArgumentException(kind.isEmpty() ? "Er is geen monster in de buurt." : "Ik zie geen '" + kind + "' in de buurt.");
		}

		double d = target.distanceTo(bot);

		if (d > 4.0) {
			JsonObject far = new JsonObject();
			far.addProperty("ok", false);
			far.addProperty("fout", target.getName().getString() + " is te ver weg (" + r1(d) + " blokken). Loop er eerst heen, ik moet binnen 4 blokken zijn.");
			far.add("pos", posArray(target.getX(), target.getY(), target.getZ()));
			return far;
		}

		lookAt(bot, target.getX(), target.getEyePosition().y, target.getZ());
		int damage = attackDamage();
		command("damage " + target.getUUID() + " " + damage + " minecraft:mob_attack by " + BOT_UUID);
		lastAttackTick = server.getTickCount();
		exhaust(0.1f);
		JsonObject o = msg("Ik sla " + target.getName().getString() + " (" + damage + " schade).");

		if (target instanceof LivingEntity living) {
			o.addProperty("levens_doelwit", r1(living.getHealth()));
		}

		return o;
	}

	private JsonObject give(Entity bot, JsonObject req) {
		ServerPlayer p = playerOrNearest(bot, s(req, "speler", ""));
		String item = s(req, "item", "");
		int count = Math.max(1, Math.min(64, req.has("aantal") ? i(req, "aantal") : 1));

		if (!ITEM_SPEC.matcher(item).matches()) {
			throw new IllegalArgumentException("Raar itemnaam: '" + item + "'.");
		}

		String id = normalizeBlock(item);
		int have = inventory.getOrDefault(id, 0);

		if (have < count) {
			throw new IllegalArgumentException("Ik heb maar " + have + "x " + id + ".");
		}

		if (p.level() != bot.level() || p.distanceTo(bot) > 6) {
			throw new IllegalArgumentException("Ik moet dichter bij " + p.getName().getString() + " staan om iets te geven.");
		}

		command("give " + p.getName().getString() + " " + id + " " + count);
		inventory.merge(id, -count, Integer::sum);

		if (inventory.get(id) <= 0) {
			inventory.remove(id);
		}

		return msg(count + "x " + id + " gegeven aan " + p.getName().getString() + ".");
	}

	// ---------------- verschijnen ----------------

	private JsonObject summon(String playerName) {
		Entity existing = find();
		ServerPlayer p = playerOrNearest(existing, playerName);
		String name = p.getName().getString();

		if (!PLAYER_NAME.matcher(name).matches()) {
			throw new IllegalArgumentException("Rare spelernaam.");
		}

		if (existing != null) {
			command("tp " + BOT_UUID + " " + name);
			path = null;
			return msg("Ik ben naar " + name + " geteleporteerd.");
		}

		if (findRaw() != null) {
			throw new IllegalArgumentException("Ik ben net doodgegaan. Wacht 2 seconden en roep me dan opnieuw.");
		}

		lastHealth = -1f;
		heldItem = "";
		worn.clear();
		sleeping = false;
		ServerLevel level = (ServerLevel) p.level();
		BlockPos pp = p.blockPosition();
		int sx = pp.getX();
		int sy = pp.getY();
		int sz = pp.getZ();
		boolean found = false;

		search:
		for (int r = 2; r >= 1; r--) {
			for (int dy = 0; dy >= -2; dy--) {
				for (int dx = -r; dx <= r; dx++) {
					for (int dz = -r; dz <= r; dz++) {
						if (Math.max(Math.abs(dx), Math.abs(dz)) != r) {
							continue;
						}

						if (PathFinder.canStand(level, pp.getX() + dx, pp.getY() + dy, pp.getZ() + dz)) {
							sx = pp.getX() + dx;
							sy = pp.getY() + dy;
							sz = pp.getZ() + dz;
							found = true;
							break search;
						}
					}
				}
			}
		}

		String uuidNbt = uuidNbt(BOT_UUID);
		String where = String.format(Locale.ROOT, "%.2f %.2f %.2f", sx + 0.5, (double) sy, sz + 0.5);
		String base = "execute at " + name + " run summon minecraft:mannequin " + where + " {" + uuidNbt
				+ ",CustomName:\"Claude\",CustomNameVisible:1b,Invulnerable:0b,hide_description:1b";

		command(base + ",profile:{texture:\"claudebuddy:entity/claude\"}}");
		boolean skin = true;

		if (find() == null) {
			// misschien snapt deze versie het skin-stukje niet: nog een keer zonder
			skin = false;
			command(base + "}");
		}

		if (find() == null) {
			throw new IllegalArgumentException("Het lukte niet om Claude te laten verschijnen. Kijk in het Minecraft-logboek (latest.log) voor de fout.");
		}

		if (creative) {
			applyModeFlags();
		}

		JsonObject o = msg("Ik sta nu bij " + name + (found ? "." : " (ik vond geen vrije plek, dus ik sta misschien raar)."));
		o.addProperty("skin_gelukt", skin);
		say("Hoi " + name + "! Ik ben er.");
		return o;
	}

	// ---------------- springen, deuren, eten ----------------

	private JsonObject jump(Entity bot, ServerLevel level) {
		if (jumpTick >= 0) {
			return msg("Ik spring al.");
		}

		BlockPos feet = bot.blockPosition();

		if (PathFinder.kindOf(level, feet.above().above()) == 1) {
			throw new IllegalArgumentException("Hier kan ik niet springen, er zit een blok boven mijn hoofd.");
		}

		path = null;
		jumpBaseY = bot.getY();
		jumpTick = 0;
		exhaust(0.05f);
		return msg("Hup!");
	}

	private JsonObject use(Entity bot, ServerLevel level, int x, int y, int z) {
		if (!inReach(bot, x, y, z, REACH)) {
			throw new IllegalArgumentException("Dat is te ver weg. Loop er eerst naartoe.");
		}

		BlockPos pos = new BlockPos(x, y, z);
		BlockState state = level.getBlockState(pos);
		lookAt(bot, x + 0.5, y + 0.5, z + 0.5);

		if (state.hasProperty(BlockStateProperties.OPEN)) {
			boolean open = !state.getValue(BlockStateProperties.OPEN);
			level.setBlock(pos, state.setValue(BlockStateProperties.OPEN, open), 10);
			return msg(blockId(state) + " is nu " + (open ? "open" : "dicht") + ".");
		}

		if (blockId(state).endsWith("lever") && state.hasProperty(BlockStateProperties.POWERED)) {
			boolean on = !state.getValue(BlockStateProperties.POWERED);
			level.setBlock(pos, state.setValue(BlockStateProperties.POWERED, on), 3);
			return msg("Hendel staat nu " + (on ? "aan" : "uit") + ".");
		}

		JsonObject more = useMore(bot, level, pos, state);

		if (more != null) {
			return more;
		}

		throw new IllegalArgumentException("Met " + blockId(state) + " kan ik met een lege hand niks doen. Ik kan deuren, luiken, hekjes, hendels, knoppen, "
				+ "nootblokken, bellen, taart, repeaters, comparators, bessenstruiken, kampvuren en bedden gebruiken. Voor kisten is er 'kist', "
				+ "en met een item in je hand: 'gebruik_item'.");
	}

	/** eten -> hongerpunten (zoals in Minecraft zelf). */
	private static final Map<String, Integer> FOODS = Map.ofEntries(
			Map.entry("minecraft:apple", 4), Map.entry("minecraft:bread", 5), Map.entry("minecraft:cooked_beef", 8),
			Map.entry("minecraft:cooked_porkchop", 8), Map.entry("minecraft:cooked_chicken", 6), Map.entry("minecraft:cooked_mutton", 6),
			Map.entry("minecraft:cooked_cod", 5), Map.entry("minecraft:cooked_salmon", 6), Map.entry("minecraft:baked_potato", 5),
			Map.entry("minecraft:carrot", 3), Map.entry("minecraft:potato", 1), Map.entry("minecraft:sweet_berries", 2),
			Map.entry("minecraft:melon_slice", 2), Map.entry("minecraft:cookie", 2), Map.entry("minecraft:golden_apple", 4),
			Map.entry("minecraft:enchanted_golden_apple", 4), Map.entry("minecraft:beef", 3), Map.entry("minecraft:porkchop", 3),
			Map.entry("minecraft:chicken", 2), Map.entry("minecraft:mutton", 2), Map.entry("minecraft:cod", 2),
			Map.entry("minecraft:salmon", 2), Map.entry("minecraft:pumpkin_pie", 8), Map.entry("minecraft:golden_carrot", 6),
			Map.entry("minecraft:cooked_rabbit", 5), Map.entry("minecraft:rabbit", 3), Map.entry("minecraft:rabbit_stew", 10),
			Map.entry("minecraft:mushroom_stew", 6), Map.entry("minecraft:beetroot_soup", 6), Map.entry("minecraft:suspicious_stew", 6),
			Map.entry("minecraft:beetroot", 1), Map.entry("minecraft:dried_kelp", 1), Map.entry("minecraft:glow_berries", 2),
			Map.entry("minecraft:honey_bottle", 6), Map.entry("minecraft:tropical_fish", 1), Map.entry("minecraft:chorus_fruit", 4),
			Map.entry("minecraft:rotten_flesh", 4), Map.entry("minecraft:spider_eye", 2), Map.entry("minecraft:poisonous_potato", 2),
			Map.entry("minecraft:pufferfish", 1));

	/** eten waar je ziek van wordt: dat eet ik niet vanzelf. */
	private static final Set<String> BAD_FOODS = Set.of("minecraft:rotten_flesh", "minecraft:spider_eye", "minecraft:poisonous_potato",
			"minecraft:pufferfish", "minecraft:chicken");

	/** wat je overhoudt na het eten. */
	private static final Map<String, String> FOOD_CONTAINERS = Map.of("minecraft:rabbit_stew", "minecraft:bowl",
			"minecraft:mushroom_stew", "minecraft:bowl", "minecraft:beetroot_soup", "minecraft:bowl",
			"minecraft:suspicious_stew", "minecraft:bowl", "minecraft:honey_bottle", "minecraft:glass_bottle");

	private void take(String id, int count) {
		inventory.merge(id, -count, Integer::sum);

		if (inventory.getOrDefault(id, 0) <= 0) {
			inventory.remove(id);
		}
	}

	private JsonObject eat(Entity bot, ServerLevel level, String item) {
		String id = item.isEmpty() ? "" : normalizeBlock(item);

		if (id.isEmpty()) {
			String best = bestFood();
			id = best == null ? "" : best;
		}

		if (id.isEmpty() || !FOODS.containsKey(id)) {
			throw new IllegalArgumentException("Ik heb niks eetbaars" + (item.isEmpty() ? "." : ": " + item + " kan ik niet eten."));
		}

		if (inventory.getOrDefault(id, 0) < 1) {
			throw new IllegalArgumentException("Ik heb geen " + id + ".");
		}

		if (hungerActive(level) && food >= 20 && !id.contains("golden_apple")) {
			throw new IllegalArgumentException("Ik zit vol (honger 20/20), ik hoef nu niks.");
		}

		eatNow(bot, level, id);
		JsonObject o = msg("Nom nom, " + id + " gegeten.");
		o.addProperty("honger", food);

		if (bot instanceof LivingEntity living) {
			o.addProperty("levens", r1(living.getHealth()));
		}

		return o;
	}

	// ================= ULTRA: honger, drinken, zitten/rijden, schild, dingen gebruiken =================

	private static boolean isPeaceful(ServerLevel level) {
		return level.getDifficulty() == Difficulty.PEACEFUL;
	}

	/** Honger telt alleen in survival en niet op vredig. */
	private boolean hungerActive(ServerLevel level) {
		return !creative && !isPeaceful(level);
	}

	private void gain(String id, int count) {
		inventory.merge(id, count, Integer::sum);
	}

	private void needItem(String id) {
		if (!infiniteBlocks && inventory.getOrDefault(id, 0) < 1) {
			throw new IllegalArgumentException("Ik heb geen " + id + " in mijn inventaris.");
		}
	}

	private void useUp(String id) {
		if (!infiniteBlocks) {
			take(id, 1);
		}
	}

	private void exhaust(float amount) {
		exhaustion += amount;
	}

	private String bestFood() {
		String best = null;

		for (String candidate : inventory.keySet()) {
			if (FOODS.containsKey(candidate) && !BAD_FOODS.contains(candidate) && (best == null || FOODS.get(candidate) > FOODS.get(best))) {
				best = candidate;
			}
		}

		return best;
	}

	private void hungerTick(Entity bot, ServerLevel level, int tick) {
		if (!(bot instanceof LivingEntity living)) {
			return;
		}

		if (!hungerActive(level)) {
			food = 20;
			saturation = 5f;
			exhaustion = 0f;
			lastHungerX = Double.NaN;

			// op vredig geneest je vanzelf, net als een speler
			if (!creative && tick % 20 == 0 && living.getHealth() < living.getMaxHealth()) {
				living.heal(1f);
			}

			return;
		}

		if (!Double.isNaN(lastHungerX) && !bot.isPassenger()) {
			double dx = bot.getX() - lastHungerX;
			double dz = bot.getZ() - lastHungerZ;
			double d = Math.sqrt(dx * dx + dz * dz);

			if (d > 0.001 && d < 3) {
				exhaust((float) d * (speed > 0.25 ? 0.1f : 0.02f));
			}
		}

		lastHungerX = bot.getX();
		lastHungerZ = bot.getZ();

		while (exhaustion >= 4f) {
			exhaustion -= 4f;

			if (saturation > 0f) {
				saturation = Math.max(0f, saturation - 1f);
			} else {
				food = Math.max(0, food - 1);
			}
		}

		if (tick % 80 == 0) {
			if (food >= 18 && living.getHealth() < living.getMaxHealth()) {
				living.heal(1f);
				exhaust(6f);
			} else if (food <= 0 && living.getHealth() > 1f) {
				// verhongeren doet pijn, maar ik ga er niet helemaal dood aan
				command("damage " + BOT_UUID + " 1 minecraft:starve");
			}
		}

		if (food <= 6 && !hungerWarned) {
			hungerWarned = true;
			simpleEvent("honger", "Ik heb honger (" + food + "/20). Ik moet iets eten" + (bestFood() == null ? ", maar ik heb geen eten bij me." : "."));
		} else if (food > 6) {
			hungerWarned = false;
		}

		if (autoEat && !sleeping && tick % 40 == 0 && food <= 14) {
			String f = bestFood();

			if (f != null && (food + FOODS.get(f) <= 20 || food <= 8)) {
				eatNow(bot, level, f);
				simpleEvent("gegeten", "Ik had trek en heb " + f + " gegeten. Honger: " + food + "/20.");
			}
		}
	}

	/** Eet 1 stuk. Met honger aan vult het je hongerbalk, anders geneest het direct. */
	private void eatNow(Entity bot, ServerLevel level, String id) {
		int points = FOODS.get(id);
		take(id, 1);
		equip(id);
		commandAsBot("playsound minecraft:entity.generic.eat neutral @a ~ ~ ~ 1 1");

		String container = FOOD_CONTAINERS.get(id);

		if (container != null) {
			gain(container, 1);
		}

		if (hungerActive(level)) {
			food = Math.min(20, food + points);
			saturation = Math.min((float) food, saturation + points * 1.2f);
		} else if (bot instanceof LivingEntity living) {
			living.heal(points);
		}

		if (id.equals("minecraft:golden_apple") || id.equals("minecraft:enchanted_golden_apple")) {
			command("effect give " + BOT_UUID + " minecraft:regeneration 10 1");
			command("effect give " + BOT_UUID + " minecraft:absorption 120 0");
		} else if (BAD_FOODS.contains(id)) {
			command("effect give " + BOT_UUID + " minecraft:hunger 20 0");
			exhaust(4f);
		}
	}

	private JsonObject drink(Entity bot, ServerLevel level, String item) {
		String id = item.isEmpty() ? "" : normalizeBlock(item);

		if (id.isEmpty()) {
			for (String candidate : new String[] {"minecraft:potion", "minecraft:milk_bucket", "minecraft:honey_bottle"}) {
				if (inventory.getOrDefault(candidate, 0) > 0) {
					id = candidate;
					break;
				}
			}
		}

		if (id.isEmpty()) {
			throw new IllegalArgumentException("Ik heb niks om te drinken (waterfles, melk of honing).");
		}

		if (inventory.getOrDefault(id, 0) < 1) {
			throw new IllegalArgumentException("Ik heb geen " + id + ".");
		}

		switch (id) {
		case "minecraft:potion":
			take(id, 1);
			gain("minecraft:glass_bottle", 1);
			equip(id);
			commandAsBot("playsound minecraft:entity.generic.drink neutral @a ~ ~ ~ 1 1");
			return msg("Slok slok, flesje leeg. (Ik onthoud niet welk soort drankje het was, dus voor mij is het water.)");
		case "minecraft:milk_bucket":
			take(id, 1);
			gain("minecraft:bucket", 1);
			equip(id);
			command("effect clear " + BOT_UUID);
			commandAsBot("playsound minecraft:entity.generic.drink neutral @a ~ ~ ~ 1 1");
			return msg("Melk gedronken: alle effecten zijn weg.");
		case "minecraft:honey_bottle":
			eatNow(bot, level, id);
			return msg("Honing gedronken. Honger: " + food + "/20.");
		default:
			throw new IllegalArgumentException(id + " kan ik niet drinken. Wel: potion (waterfles), milk_bucket, honey_bottle.");
		}
	}

	/** Wordt door de mod aangeroepen voor ELKE klap op een levend wezen. false = de klap telt niet. */
	public boolean allowDamage(Entity entity, DamageSource source, float amount) {
		if (!BOT_UUID.equals(entity.getUUID())) {
			return true;
		}

		if (creative) {
			return false;
		}

		if (blocking && inventory.containsKey("minecraft:shield") && source.getEntity() != null) {
			command("execute at " + BOT_UUID + " run playsound minecraft:item.shield.block neutral @a ~ ~ ~ 1 1");
			return false;
		}

		return true;
	}

	private JsonObject shieldUp(boolean up) {
		if (up && !inventory.containsKey("minecraft:shield")) {
			throw new IllegalArgumentException("Ik heb geen schild. Geef me er een, of maak er een (6 planken + 1 ijzer).");
		}

		blocking = up;
		return msg(up ? "Schild omhoog! Klappen en pijlen van wezens en spelers houd ik nu tegen."
				: "Schild omlaag.");
	}

	private static final String[] RIDEABLE = {"cushion", "boat", "raft", "minecart", "horse", "donkey", "mule", "camel", "pig",
			"strider", "nautilus", "llama", "happy_ghast"};

	private JsonObject ride(Entity bot, ServerLevel level, String kind) {
		String want = kind.toLowerCase(Locale.ROOT);
		Entity target = null;
		double best = Double.MAX_VALUE;

		for (Entity e : level.getEntities(bot, bot.getBoundingBox().inflate(6))) {
			if (e instanceof ServerPlayer || e instanceof ItemEntity || !e.isAlive()) {
				continue;
			}

			String id = entityId(e);
			boolean ok = false;

			if (want.isEmpty()) {
				for (String r : RIDEABLE) {
					ok = ok || id.contains(r);
				}
			} else {
				ok = id.contains(want);
			}

			if (ok && e.distanceTo(bot) < best) {
				best = e.distanceTo(bot);
				target = e;
			}
		}

		if (target == null) {
			throw new IllegalArgumentException(want.isEmpty() ? "Ik zie hier niks om op te zitten of te rijden (binnen 6 blokken)."
					: "Ik zie geen '" + kind + "' binnen 6 blokken.");
		}

		path = null;
		flyTarget = null;
		followName = null;
		jumpTick = -1;

		if (bot.isPassenger()) {
			command("ride " + BOT_UUID + " dismount");
		}

		command("ride " + BOT_UUID + " mount " + target.getUUID());

		if (!bot.isPassenger()) {
			throw new IllegalArgumentException("Opstappen op " + entityId(target) + " lukte niet (misschien zit er al iemand op).");
		}

		JsonObject o = msg("Ik zit op " + entityId(target) + ". Sturen kan ik zelf niet; met 'stap_af' sta ik weer op.");
		o.addProperty("zit_op", entityId(target));
		return o;
	}

	private JsonObject dismount(Entity bot) {
		if (!bot.isPassenger()) {
			return msg("Ik zat nergens op.");
		}

		command("ride " + BOT_UUID + " dismount");
		return msg("Ik ben afgestapt.");
	}

	// ---- blokstaten lezen en zetten via tekst, zodat het met elk blok werkt ----

	private static String props(BlockState state) {
		String t = state.toString();
		int i = t.indexOf('[');
		return i < 0 ? "" : t.substring(i);
	}

	private static String prop(BlockState state, String key) {
		String p = props(state);

		if (p.length() < 3) {
			return "";
		}

		for (String kv : p.substring(1, p.length() - 1).split(",")) {
			String[] a = kv.split("=");

			if (a.length == 2 && a[0].equals(key)) {
				return a[1];
			}
		}

		return "";
	}

	/** Zelfde blok, maar met 1 eigenschap anders, bijvoorbeeld lit=true. */
	private static String withProp(BlockState state, String key, String value) {
		return withProp(blockId(state), state, key, value);
	}

	private static String withProp(String id, BlockState state, String key, String value) {
		String p = props(state);
		StringBuilder sb = new StringBuilder(id).append('[');
		boolean found = false;

		if (p.length() >= 3) {
			for (String kv : p.substring(1, p.length() - 1).split(",")) {
				String[] a = kv.split("=");

				if (a.length != 2) {
					continue;
				}

				if (a[0].equals(key)) {
					found = true;
					sb.append(key).append('=').append(value).append(',');
				} else {
					sb.append(kv).append(',');
				}
			}
		}

		if (!found && key != null) {
			sb.append(key).append('=').append(value).append(',');
		}

		if (sb.charAt(sb.length() - 1) == ',') {
			sb.setLength(sb.length() - 1);
		}

		return sb.length() == id.length() + 1 ? id : sb.append(']').toString();
	}

	private void setBlockSpec(BlockPos pos, String spec) {
		command("setblock " + pos.getX() + " " + pos.getY() + " " + pos.getZ() + " " + spec + " replace");
	}

	private void soundAt(BlockPos pos, String sound) {
		command("playsound " + sound + " block @a " + pos.getX() + " " + pos.getY() + " " + pos.getZ() + " 1 1");
	}

	private void buttonTick(ServerLevel level, int tick) {
		for (int k = buttonResets.size() - 1; k >= 0; k--) {
			int[] b = buttonResets.get(k);

			if (tick >= b[3]) {
				buttonResets.remove(k);
				BlockPos pos = new BlockPos(b[0], b[1], b[2]);
				BlockState state = level.getBlockState(pos);

				if (blockId(state).endsWith("_button") && prop(state, "powered").equals("true")) {
					setBlockSpec(pos, withProp(state, "powered", "false"));
				}
			}
		}
	}

	/** Alles wat je met een lege hand met een blok kunt doen. Geeft null als ik niks met dit blok kan. */
	private JsonObject useMore(Entity bot, ServerLevel level, BlockPos pos, BlockState state) {
		String id = blockId(state);
		String name = id.substring(id.indexOf(':') + 1);

		if (name.endsWith("_button")) {
			setBlockSpec(pos, withProp(state, "powered", "true"));
			buttonResets.add(new int[] {pos.getX(), pos.getY(), pos.getZ(), server.getTickCount() + (name.startsWith("stone") || name.startsWith("polished") ? 20 : 30)});
			soundAt(pos, "minecraft:block.stone_button.click_on");
			return msg("Knop ingedrukt.");
		}

		if (name.equals("note_block")) {
			soundAt(pos, "minecraft:block.note_block.harp");
			return msg("Pling! Nootblok bespeeld.");
		}

		if (name.equals("bell")) {
			soundAt(pos, "minecraft:block.bell.use");
			return msg("Ding dong! Ik heb de bel geluid.");
		}

		if (name.equals("cake")) {
			int bites = prop(state, "bites").isEmpty() ? 0 : Integer.parseInt(prop(state, "bites"));
			setBlockSpec(pos, bites >= 6 ? "minecraft:air" : withProp(state, "bites", String.valueOf(bites + 1)));

			if (hungerActive(level)) {
				food = Math.min(20, food + 2);
				saturation = Math.min((float) food, saturation + 0.4f);
			}

			return msg("Mmm, een stuk taart gegeten. Honger: " + food + "/20.");
		}

		if (name.equals("repeater")) {
			int delay = prop(state, "delay").isEmpty() ? 1 : Integer.parseInt(prop(state, "delay"));
			int next = delay >= 4 ? 1 : delay + 1;
			setBlockSpec(pos, withProp(state, "delay", String.valueOf(next)));
			return msg("Repeater staat nu op vertraging " + next + ".");
		}

		if (name.equals("comparator")) {
			String next = prop(state, "mode").equals("compare") ? "subtract" : "compare";
			setBlockSpec(pos, withProp(state, "mode", next));
			return msg("Comparator staat nu op " + next + ".");
		}

		if (name.equals("daylight_detector")) {
			String next = prop(state, "inverted").equals("true") ? "false" : "true";
			setBlockSpec(pos, withProp(state, "inverted", next));
			return msg("Daglichtsensor omgedraaid.");
		}

		if (name.equals("sweet_berry_bush")) {
			int age = prop(state, "age").isEmpty() ? 0 : Integer.parseInt(prop(state, "age"));

			if (age < 2) {
				throw new IllegalArgumentException("Deze bessenstruik heeft nog geen bessen.");
			}

			setBlockSpec(pos, withProp(state, "age", "1"));
			gain("minecraft:sweet_berries", age >= 3 ? 3 : 2);
			return msg("Bessen geplukt.");
		}

		if ((name.endsWith("campfire") || name.endsWith("candle")) && prop(state, "lit").equals("true")) {
			setBlockSpec(pos, withProp(state, "lit", "false"));
			return msg(id + " is uitgedoofd.");
		}

		if (name.endsWith("_bed")) {
			return sleep(bot, level);
		}

		return null;
	}

	private static final Map<String, String> SEEDS = Map.ofEntries(
			Map.entry("minecraft:wheat_seeds", "minecraft:wheat"), Map.entry("minecraft:carrot", "minecraft:carrots"),
			Map.entry("minecraft:potato", "minecraft:potatoes"), Map.entry("minecraft:beetroot_seeds", "minecraft:beetroots"),
			Map.entry("minecraft:melon_seeds", "minecraft:melon_stem"), Map.entry("minecraft:pumpkin_seeds", "minecraft:pumpkin_stem"),
			Map.entry("minecraft:torchflower_seeds", "minecraft:torchflower_crop"));

	/** Een item uit je inventaris op een blok gebruiken (rechtsklikken met iets in je hand). */
	private JsonObject useItemOn(Entity bot, ServerLevel level, String itemSpec, int x, int y, int z) {
		if (!inReach(bot, x, y, z, REACH)) {
			throw new IllegalArgumentException("Dat is te ver weg. Loop er eerst naartoe.");
		}

		String item = normalizeBlock(itemSpec);
		String itemName = item.substring(item.indexOf(':') + 1);
		needItem(item);

		BlockPos pos = new BlockPos(x, y, z);
		BlockState state = level.getBlockState(pos);
		String id = blockId(state);
		String name = id.substring(id.indexOf(':') + 1);
		BlockPos up = pos.above();
		boolean airAbove = level.getBlockState(up).isAir();
		lookAt(bot, x + 0.5, y + 0.5, z + 0.5);
		equip(item);

		// emmers
		if (itemName.equals("water_bucket") || itemName.equals("lava_bucket")) {
			BlockPos target = state.isAir() || !state.getFluidState().isEmpty() ? pos : up;

			if (!level.getBlockState(target).isAir() && level.getBlockState(target).getFluidState().isEmpty()) {
				throw new IllegalArgumentException("Daar is geen plek om de emmer leeg te gieten.");
			}

			setBlockSpec(target, itemName.equals("water_bucket") ? "minecraft:water" : "minecraft:lava");

			if (!infiniteBlocks) {
				take(item, 1);
				gain("minecraft:bucket", 1);
			}

			return msg("Emmer leeggegoten op " + target.getX() + " " + target.getY() + " " + target.getZ() + ".");
		}

		if (itemName.equals("bucket")) {
			if ((name.equals("water") || name.equals("lava")) && prop(state, "level").equals("0")) {
				setBlockSpec(pos, "minecraft:air");
				useUp(item);
				gain("minecraft:" + name + "_bucket", 1);
				return msg("Emmer gevuld met " + name + ".");
			}

			throw new IllegalArgumentException("Met een lege emmer kan ik alleen een bronblok water of lava opscheppen.");
		}

		if (itemName.equals("glass_bottle")) {
			if (name.equals("water")) {
				useUp(item);
				gain("minecraft:potion", 1);
				return msg("Flesje gevuld met water.");
			}

			throw new IllegalArgumentException("Een flesje kan ik alleen in water vullen.");
		}

		// vuur
		if (itemName.equals("flint_and_steel")) {
			if (name.equals("tnt")) {
				setBlockSpec(pos, "minecraft:air");
				command("summon minecraft:tnt " + (x + 0.5) + " " + y + " " + (z + 0.5) + " {fuse:80}");
				return msg("TNT aangestoken! Wegwezen!");
			}

			if ((name.endsWith("campfire") || name.endsWith("candle")) && prop(state, "lit").equals("false")) {
				setBlockSpec(pos, withProp(state, "lit", "true"));
				return msg(id + " brandt nu.");
			}

			BlockPos target = state.isAir() ? pos : up;

			if (!level.getBlockState(target).isAir()) {
				throw new IllegalArgumentException("Daar kan geen vuur.");
			}

			setBlockSpec(target, "minecraft:fire");
			return msg("Vuur gemaakt.");
		}

		// botmeel
		if (itemName.equals("bone_meal")) {
			if (!BoneMealItem.growCrop(stackOf(item), level, pos)) {
				throw new IllegalArgumentException("Botmeel werkt hier niet (het moet een plant zijn die nog kan groeien).");
			}

			useUp(item);
			return msg("Botmeel gestrooid, het groeit!");
		}

		// schoffel, schep, bijl, schaar
		if (itemName.endsWith("_hoe")) {
			if ((name.equals("dirt") || name.equals("grass_block") || name.equals("dirt_path")) && airAbove) {
				setBlockSpec(pos, "minecraft:farmland");
				return msg("Akker gemaakt. Hier kan ik zaadjes planten.");
			}

			if (name.equals("coarse_dirt") || name.equals("rooted_dirt")) {
				setBlockSpec(pos, "minecraft:dirt");
				return msg("Omgeschoffeld naar gewone aarde.");
			}

			throw new IllegalArgumentException("Schoffelen kan alleen op aarde of gras met lucht erboven.");
		}

		if (itemName.endsWith("_shovel")) {
			if (name.endsWith("campfire") && prop(state, "lit").equals("true")) {
				setBlockSpec(pos, withProp(state, "lit", "false"));
				return msg("Kampvuur gedoofd.");
			}

			if ((name.equals("grass_block") || name.equals("dirt") || name.equals("coarse_dirt") || name.equals("podzol")
					|| name.equals("mycelium") || name.equals("rooted_dirt")) && airAbove) {
				setBlockSpec(pos, "minecraft:dirt_path");
				return msg("Paadje gemaakt.");
			}

			throw new IllegalArgumentException("Met een schep kan ik hier geen pad maken.");
		}

		if (itemName.endsWith("_axe")) {
			if (!name.startsWith("stripped_") && inGroup("#logs", id)) {
				setBlockSpec(pos, withProp("minecraft:stripped_" + name, state, null, null));
				return msg("Schors eraf gehaald: stripped_" + name + ".");
			}

			throw new IllegalArgumentException("Met een bijl kan ik alleen de schors van een stam halen.");
		}

		if (itemName.equals("shears")) {
			if (name.equals("pumpkin")) {
				setBlockSpec(pos, "minecraft:carved_pumpkin");
				gain("minecraft:pumpkin_seeds", 4);
				return msg("Pompoen uitgesneden.");
			}

			throw new IllegalArgumentException("Met een schaar kan ik hier niks. Voor schapen: gebruik_op_dier.");
		}

		// planten
		if (SEEDS.containsKey(item)) {
			if (!name.equals("farmland") || !airAbove) {
				throw new IllegalArgumentException("Zaadjes moeten op een akker (farmland) met lucht erboven. Maak die eerst met een schoffel.");
			}

			setBlockSpec(up, SEEDS.get(item));
			useUp(item);
			return msg("Geplant: " + SEEDS.get(item) + ".");
		}

		if (itemName.equals("nether_wart")) {
			if (!name.equals("soul_sand") || !airAbove) {
				throw new IllegalArgumentException("Nether wart moet op soul sand.");
			}

			setBlockSpec(up, "minecraft:nether_wart");
			useUp(item);
			return msg("Nether wart geplant.");
		}

		throw new IllegalArgumentException("Ik weet niet hoe ik " + item + " op " + id + " moet gebruiken. Dit kan ik wel: emmers, glass_bottle, "
				+ "flint_and_steel, bone_meal, schoffel, schep, bijl, schaar, zaadjes. Blokken neerzetten doe je met 'plaats'.");
	}

	private static final String[][] BREED_FOOD = {
			{"cow", "wheat"}, {"mooshroom", "wheat"}, {"sheep", "wheat"}, {"goat", "wheat"}, {"pig", "carrot"}, {"pig", "potato"},
			{"pig", "beetroot"}, {"chicken", "wheat_seeds"}, {"chicken", "beetroot_seeds"}, {"chicken", "melon_seeds"},
			{"chicken", "pumpkin_seeds"}, {"horse", "golden_carrot"}, {"horse", "golden_apple"}, {"donkey", "golden_carrot"},
			{"rabbit", "carrot"}, {"rabbit", "dandelion"}, {"cat", "cod"}, {"cat", "salmon"}, {"wolf", "beef"}, {"wolf", "cooked_beef"},
			{"wolf", "porkchop"}, {"wolf", "chicken"}, {"wolf", "mutton"}, {"llama", "hay_block"}, {"fox", "sweet_berries"},
			{"bee", "dandelion"}, {"bee", "poppy"}, {"turtle", "seagrass"}, {"panda", "bamboo"}, {"camel", "cactus"},
			{"strider", "warped_fungus"}, {"hoglin", "crimson_fungus"}, {"axolotl", "tropical_fish_bucket"}, {"frog", "slime_ball"},
			{"sniffer", "torchflower_seeds"}, {"armadillo", "spider_eye"}, {"nautilus", "pufferfish"}};

	/** Een item uit je inventaris op een dier gebruiken: scheren, melken, zadelen, voeren, temmen. */
	private JsonObject useItemOnEntity(Entity bot, ServerLevel level, String itemSpec, String kind) {
		String item = normalizeBlock(itemSpec);
		String itemName = item.substring(item.indexOf(':') + 1);
		needItem(item);
		String want = kind.toLowerCase(Locale.ROOT);
		Entity target = null;
		double best = Double.MAX_VALUE;

		for (Entity e : level.getEntities(bot, bot.getBoundingBox().inflate(5))) {
			if (e instanceof LivingEntity && !(e instanceof ServerPlayer) && e.isAlive()
					&& (want.isEmpty() || entityId(e).contains(want)) && e.distanceTo(bot) < best) {
				best = e.distanceTo(bot);
				target = e;
			}
		}

		if (target == null) {
			throw new IllegalArgumentException(want.isEmpty() ? "Er is geen dier binnen 5 blokken." : "Ik zie geen '" + kind + "' binnen 5 blokken.");
		}

		String animal = entityId(target);
		animal = animal.substring(animal.indexOf(':') + 1);
		String uuid = target.getUUID().toString();
		lookAt(bot, target.getX(), target.getEyePosition().y, target.getZ());
		equip(item);

		if (itemName.equals("shears") && animal.equals("sheep")) {
			command("data merge entity " + uuid + " {Sheared:1b}");
			gain("minecraft:white_wool", 2);
			commandAsBot("playsound minecraft:entity.sheep.shear neutral @a ~ ~ ~ 1 1");
			return msg("Schaap geschoren, 2 wol erbij. (Ik krijg altijd witte wol, de kleur kan ik niet zien.)");
		}

		if (itemName.equals("bucket") && (animal.equals("cow") || animal.equals("goat") || animal.equals("mooshroom"))) {
			useUp(item);
			gain("minecraft:milk_bucket", 1);
			return msg("Gemolken! Ik heb een emmer melk.");
		}

		if (itemName.equals("bowl") && animal.equals("mooshroom")) {
			useUp(item);
			gain("minecraft:mushroom_stew", 1);
			return msg("Paddenstoelensoep getapt uit de mooshroom.");
		}

		if (itemName.equals("saddle")) {
			command("item replace entity " + uuid + " saddle with minecraft:saddle");
			useUp(item);
			return msg("Zadel op de " + animal + " gelegd. Met 'rijd' kan ik erop gaan zitten.");
		}

		if (itemName.equals("pufferfish") && animal.contains("nautilus")) {
			useUp(item);

			if (Math.random() < 1.0 / 3.0) {
				ServerPlayer owner = playerOrNearest(bot, "");
				command("data merge entity " + uuid + " {" + uuidNbt(owner.getUUID()).replace("UUID:", "Owner:") + "}");
				command("particle minecraft:heart " + target.getX() + " " + (target.getY() + 1) + " " + target.getZ() + " 0.4 0.4 0.4 0 7");
				return msg("Gelukt, de nautilus is getemd! Hij is nu van " + owner.getName().getString() + ".");
			}

			return msg("De nautilus at de kogelvis op, maar is nog niet tam. Nog een keer proberen (1 op 3 kans).");
		}

		for (String[] bf : BREED_FOOD) {
			if (animal.contains(bf[0]) && itemName.equals(bf[1])) {
				useUp(item);
				command("data merge entity " + uuid + " {InLove:600}");
				command("particle minecraft:heart " + target.getX() + " " + (target.getY() + 1) + " " + target.getZ() + " 0.4 0.4 0.4 0 7");
				return msg("De " + animal + " is gevoerd en verliefd. Voer er nog een, dan komt er een baby.");
			}
		}

		throw new IllegalArgumentException("Ik weet niet wat " + item + " met een " + animal + " doet. Dit kan: schaar op schaap, emmer op koe/geit, "
				+ "kom op mooshroom, zadel op rijdier, kogelvis op nautilus, en het lievelingseten van een dier om te fokken.");
	}

	// ---------------- craften en smelten ----------------

	/** naam, aantal dat je krijgt, werkbank nodig, ingredienten als "aantal*item" (# = groep). */
	private static final String[][] RECIPES = {
			{"stick", "4", "nee", "2*#planks"},
			{"crafting_table", "1", "nee", "4*#planks"},
			{"torch", "4", "nee", "1*#coal", "1*stick"},
			{"chest", "1", "ja", "8*#planks"},
			{"furnace", "1", "ja", "8*#stone"},
			{"oak_door", "3", "ja", "6*#planks"},
			{"oak_boat", "1", "ja", "5*#planks"},
			{"ladder", "3", "ja", "7*stick"},
			{"bowl", "4", "ja", "3*#planks"},
			{"white_bed", "1", "ja", "3*#wool", "3*#planks"},
			{"bucket", "1", "ja", "3*iron_ingot"},
			{"shears", "1", "nee", "2*iron_ingot"},
			{"flint_and_steel", "1", "nee", "1*iron_ingot", "1*flint"},
			{"shield", "1", "ja", "6*#planks", "1*iron_ingot"},
			{"bow", "1", "ja", "3*stick", "3*string"},
			{"arrow", "4", "ja", "1*flint", "1*stick", "1*feather"},
			{"bread", "1", "ja", "3*wheat"},
			{"campfire", "1", "ja", "3*stick", "1*#coal", "3*#logs"},
			{"stone_bricks", "4", "ja", "4*stone"},
			{"wooden_pickaxe", "1", "ja", "3*#planks", "2*stick"},
			{"wooden_axe", "1", "ja", "3*#planks", "2*stick"},
			{"wooden_shovel", "1", "ja", "1*#planks", "2*stick"},
			{"wooden_sword", "1", "ja", "2*#planks", "1*stick"},
			{"wooden_hoe", "1", "ja", "2*#planks", "2*stick"},
			{"stone_pickaxe", "1", "ja", "3*#stone", "2*stick"},
			{"stone_axe", "1", "ja", "3*#stone", "2*stick"},
			{"stone_shovel", "1", "ja", "1*#stone", "2*stick"},
			{"stone_sword", "1", "ja", "2*#stone", "1*stick"},
			{"stone_hoe", "1", "ja", "2*#stone", "2*stick"},
			{"iron_pickaxe", "1", "ja", "3*iron_ingot", "2*stick"},
			{"iron_axe", "1", "ja", "3*iron_ingot", "2*stick"},
			{"iron_shovel", "1", "ja", "1*iron_ingot", "2*stick"},
			{"iron_sword", "1", "ja", "2*iron_ingot", "1*stick"},
			{"iron_hoe", "1", "ja", "2*iron_ingot", "2*stick"},
			{"diamond_pickaxe", "1", "ja", "3*diamond", "2*stick"},
			{"diamond_axe", "1", "ja", "3*diamond", "2*stick"},
			{"diamond_shovel", "1", "ja", "1*diamond", "2*stick"},
			{"diamond_sword", "1", "ja", "2*diamond", "1*stick"},
			{"iron_helmet", "1", "ja", "5*iron_ingot"},
			{"iron_chestplate", "1", "ja", "8*iron_ingot"},
			{"iron_leggings", "1", "ja", "7*iron_ingot"},
			{"iron_boots", "1", "ja", "4*iron_ingot"},
			{"diamond_hoe", "1", "ja", "2*diamond", "2*stick"},
			{"diamond_helmet", "1", "ja", "5*diamond"},
			{"diamond_chestplate", "1", "ja", "8*diamond"},
			{"diamond_leggings", "1", "ja", "7*diamond"},
			{"diamond_boots", "1", "ja", "4*diamond"},
			{"golden_pickaxe", "1", "ja", "3*gold_ingot", "2*stick"},
			{"golden_sword", "1", "ja", "2*gold_ingot", "1*stick"},
			{"golden_helmet", "1", "ja", "5*gold_ingot"},
			{"golden_chestplate", "1", "ja", "8*gold_ingot"},
			{"golden_leggings", "1", "ja", "7*gold_ingot"},
			{"golden_boots", "1", "ja", "4*gold_ingot"},
			{"leather_helmet", "1", "ja", "5*leather"},
			{"leather_chestplate", "1", "ja", "8*leather"},
			{"leather_leggings", "1", "ja", "7*leather"},
			{"leather_boots", "1", "ja", "4*leather"},
			{"saddle", "1", "ja", "3*leather", "1*iron_ingot"},
			{"fishing_rod", "1", "ja", "3*stick", "2*string"},
			{"lead", "2", "ja", "5*string"},
			{"white_wool", "1", "nee", "4*string"},
			{"lever", "1", "nee", "1*stick", "1*#stone"},
			{"stone_button", "1", "nee", "1*stone"},
			{"oak_button", "1", "nee", "1*#planks"},
			{"oak_pressure_plate", "1", "nee", "2*#planks"},
			{"stone_pressure_plate", "1", "nee", "2*stone"},
			{"redstone_torch", "1", "nee", "1*redstone", "1*stick"},
			{"repeater", "1", "ja", "3*stone", "2*redstone_torch", "1*redstone"},
			{"comparator", "1", "ja", "3*stone", "3*redstone_torch", "1*quartz"},
			{"piston", "1", "ja", "3*#planks", "4*#stone", "1*iron_ingot", "1*redstone"},
			{"sticky_piston", "1", "nee", "1*piston", "1*slime_ball"},
			{"redstone_lamp", "1", "ja", "4*redstone", "1*glowstone"},
			{"note_block", "1", "ja", "8*#planks", "1*redstone"},
			{"dispenser", "1", "ja", "7*#stone", "1*bow", "1*redstone"},
			{"dropper", "1", "ja", "7*#stone", "1*redstone"},
			{"observer", "1", "ja", "6*#stone", "2*redstone", "1*quartz"},
			{"hopper", "1", "ja", "5*iron_ingot", "1*chest"},
			{"redstone_block", "1", "ja", "9*redstone"},
			{"tnt", "1", "ja", "5*gunpowder", "4*sand"},
			{"rail", "16", "ja", "6*iron_ingot", "1*stick"},
			{"minecart", "1", "ja", "5*iron_ingot"},
			{"oak_trapdoor", "2", "ja", "6*#planks"},
			{"oak_fence", "3", "ja", "4*#planks", "2*stick"},
			{"oak_fence_gate", "1", "ja", "2*#planks", "4*stick"},
			{"oak_sign", "3", "ja", "6*#planks", "1*stick"},
			{"oak_slab", "6", "ja", "3*#planks"},
			{"oak_stairs", "4", "ja", "6*#planks"},
			{"cobblestone_slab", "6", "ja", "3*cobblestone"},
			{"cobblestone_stairs", "4", "ja", "6*cobblestone"},
			{"cobblestone_wall", "6", "ja", "6*cobblestone"},
			{"stone_brick_stairs", "4", "ja", "6*stone_bricks"},
			{"barrel", "1", "ja", "6*#planks", "2*oak_slab"},
			{"bookshelf", "1", "ja", "6*#planks", "3*book"},
			{"book", "1", "nee", "3*paper", "1*leather"},
			{"paper", "3", "ja", "3*sugar_cane"},
			{"sugar", "1", "nee", "1*sugar_cane"},
			{"glass_pane", "16", "ja", "6*glass"},
			{"glass_bottle", "3", "ja", "3*glass"},
			{"iron_bars", "16", "ja", "6*iron_ingot"},
			{"iron_door", "3", "ja", "6*iron_ingot"},
			{"iron_block", "1", "ja", "9*iron_ingot"},
			{"gold_block", "1", "ja", "9*gold_ingot"},
			{"diamond_block", "1", "ja", "9*diamond"},
			{"coal_block", "1", "ja", "9*coal"},
			{"anvil", "1", "ja", "3*iron_block", "4*iron_ingot"},
			{"lantern", "1", "ja", "8*iron_nugget", "1*torch"},
			{"iron_nugget", "9", "nee", "1*iron_ingot"},
			{"smoker", "1", "ja", "1*furnace", "4*#logs"},
			{"blast_furnace", "1", "ja", "5*iron_ingot", "1*furnace", "3*smooth_stone"},
			{"compass", "1", "ja", "4*iron_ingot", "1*redstone"},
			{"clock", "1", "ja", "4*gold_ingot", "1*redstone"},
			{"bone_meal", "3", "nee", "1*bone"},
			{"hay_block", "1", "ja", "9*wheat"},
			{"cookie", "8", "ja", "2*wheat", "1*cocoa_beans"},
			{"pumpkin_pie", "1", "nee", "1*pumpkin", "1*sugar", "1*egg"},
			{"golden_apple", "1", "ja", "8*gold_ingot", "1*apple"},
			{"golden_carrot", "1", "ja", "8*gold_nugget", "1*carrot"},
			{"gold_nugget", "9", "nee", "1*gold_ingot"},
			{"mushroom_stew", "1", "nee", "1*red_mushroom", "1*brown_mushroom", "1*bowl"},
			{"melon", "1", "ja", "9*melon_slice"},
			{"bricks", "1", "nee", "4*brick"},
			{"flower_pot", "1", "ja", "3*brick"},
			{"painting", "1", "ja", "8*stick", "1*#wool"},
			{"item_frame", "1", "ja", "8*stick", "1*leather"},
			{"armor_stand", "1", "ja", "6*stick", "1*smooth_stone_slab"},
			{"smooth_stone_slab", "6", "ja", "3*smooth_stone"},
	};

	/** wat erin gaat -> wat eruit komt (oven nodig, en brandstof). */
	private static final String[][] SMELTS = {
			{"iron_ingot", "raw_iron"}, {"iron_ingot", "iron_ore"}, {"gold_ingot", "raw_gold"}, {"copper_ingot", "raw_copper"},
			{"glass", "sand"}, {"stone", "cobblestone"}, {"smooth_stone", "stone"}, {"charcoal", "#logs"}, {"brick", "clay_ball"},
			{"cooked_beef", "beef"}, {"cooked_porkchop", "porkchop"}, {"cooked_chicken", "chicken"}, {"cooked_mutton", "mutton"},
			{"cooked_cod", "cod"}, {"cooked_salmon", "salmon"}, {"baked_potato", "potato"},
			{"cooked_rabbit", "rabbit"}, {"dried_kelp", "kelp"}, {"iron_ingot", "deepslate_iron_ore"},
			{"gold_ingot", "gold_ore"}, {"gold_ingot", "deepslate_gold_ore"}, {"copper_ingot", "copper_ore"},
			{"copper_ingot", "deepslate_copper_ore"}, {"deepslate", "cobbled_deepslate"}, {"terracotta", "clay"},
			{"nether_brick", "netherrack"}, {"netherite_scrap", "ancient_debris"}, {"sponge", "wet_sponge"},
			{"green_dye", "cactus"}, {"cracked_stone_bricks", "stone_bricks"}, {"smooth_sandstone", "sandstone"},
			{"popped_chorus_fruit", "chorus_fruit"},
	};

	private static boolean inGroup(String group, String id) {
		String name = id.substring(id.indexOf(':') + 1);

		switch (group) {
		case "#planks":
			return name.endsWith("_planks");
		case "#logs":
			return name.endsWith("_log") || name.endsWith("_stem") || name.endsWith("_wood") || name.endsWith("_hyphae");
		case "#stone":
			return name.equals("cobblestone") || name.equals("cobbled_deepslate") || name.equals("blackstone");
		case "#coal":
			return name.equals("coal") || name.equals("charcoal");
		case "#wool":
			return name.endsWith("_wool");
		default:
			return false;
		}
	}

	private int have(String ingredient) {
		if (!ingredient.startsWith("#")) {
			return inventory.getOrDefault("minecraft:" + ingredient, 0);
		}

		int total = 0;

		for (Map.Entry<String, Integer> en : inventory.entrySet()) {
			if (inGroup(ingredient, en.getKey())) {
				total += en.getValue();
			}
		}

		return total;
	}

	private void spend(String ingredient, int count) {
		if (!ingredient.startsWith("#")) {
			take("minecraft:" + ingredient, count);
			return;
		}

		for (String id : new ArrayList<>(inventory.keySet())) {
			if (count <= 0) {
				break;
			}

			if (inGroup(ingredient, id)) {
				int n = Math.min(count, inventory.get(id));
				take(id, n);
				count -= n;
			}
		}
	}

	private boolean blockNearby(Entity bot, ServerLevel level, String idPart) {
		BlockPos c = bot.blockPosition();

		for (int x = -4; x <= 4; x++) {
			for (int y = -3; y <= 3; y++) {
				for (int z = -4; z <= 4; z++) {
					if (blockId(level.getBlockState(new BlockPos(c.getX() + x, c.getY() + y, c.getZ() + z))).endsWith(idPart)) {
						return true;
					}
				}
			}
		}

		return false;
	}

	private JsonObject recipeList() {
		JsonObject o = new JsonObject();
		JsonArray craft = new JsonArray();
		craft.add("planks: 1 boomstam -> 4 planken (geen werkbank nodig)");

		for (String[] r : RECIPES) {
			StringBuilder sb = new StringBuilder(r[0] + " x" + r[1] + (r[2].equals("ja") ? " [werkbank]" : "") + " = ");

			for (int k = 3; k < r.length; k++) {
				sb.append(k > 3 ? " + " : "").append(r[k]);
			}

			craft.add(sb.toString());
		}

		JsonArray smelt = new JsonArray();

		for (String[] r : SMELTS) {
			smelt.add(r[1] + " -> " + r[0]);
		}

		o.add("craften", craft);
		o.add("smelten_in_oven", smelt);
		o.addProperty("uitleg", "# = groep (alle soorten planken, stammen, steen, kolen, wol). Smelten heeft een oven dichtbij nodig en brandstof: 1 kool per 8, of 1 plank/stam per stuk.");
		return o;
	}

	private JsonObject craft(Entity bot, ServerLevel level, String item, int times) {
		String name = item.replace("minecraft:", "").toLowerCase(Locale.ROOT);
		times = Math.min(times, 64);

		// planken: hangt af van de houtsoort
		if (name.equals("planks") || name.endsWith("_planks")) {
			int made = 0;

			for (String id : new ArrayList<>(inventory.keySet())) {
				while (made < times && inGroup("#logs", id) && inventory.getOrDefault(id, 0) > 0) {
					String wood = id.replace("stripped_", "").replaceAll("_(log|stem|wood|hyphae)$", "") + "_planks";
					take(id, 1);
					inventory.merge(wood, 4, Integer::sum);
					made++;
				}
			}

			if (made == 0) {
				throw new IllegalArgumentException("Ik heb geen boomstammen om planken van te maken.");
			}

			return msg(made + " boomstam(men) gezaagd tot " + (made * 4) + " planken.");
		}

		for (String[] r : RECIPES) {
			if (!r[0].equals(name)) {
				continue;
			}

			if (r[2].equals("ja") && !blockNearby(bot, level, "crafting_table")) {
				throw new IllegalArgumentException("Hiervoor heb ik een werkbank nodig binnen 4 blokken. Maak er een (4 planken) en zet hem neer.");
			}

			for (int k = 3; k < r.length; k++) {
				String[] part = r[k].split("\\*");
				int need = Integer.parseInt(part[0]) * times;

				if (have(part[1]) < need) {
					throw new IllegalArgumentException("Ik kom tekort: ik heb " + have(part[1]) + " van " + part[1] + " en ik heb er " + need + " nodig.");
				}
			}

			for (int k = 3; k < r.length; k++) {
				String[] part = r[k].split("\\*");
				spend(part[1], Integer.parseInt(part[0]) * times);
			}

			int out = Integer.parseInt(r[1]) * times;
			inventory.merge("minecraft:" + name, out, Integer::sum);
			equip("minecraft:" + name);
			return msg(out + "x " + name + " gemaakt.");
		}

		for (String[] r : SMELTS) {
			if (!r[0].equals(name) || have(r[1]) < 1) {
				continue;
			}

			if (!blockNearby(bot, level, "furnace")) {
				throw new IllegalArgumentException("Hiervoor heb ik een oven nodig binnen 4 blokken.");
			}

			int n = Math.min(times, have(r[1]));
			int coalNeeded = (n + 7) / 8;

			if (have("#coal") >= coalNeeded) {
				spend("#coal", coalNeeded);
			} else if (have("#planks") >= n) {
				spend("#planks", n);
			} else if (!r[1].equals("#logs") && have("#logs") >= n) {
				spend("#logs", n);
			} else {
				throw new IllegalArgumentException("Ik heb geen brandstof: " + coalNeeded + " kool/houtskool, of " + n + " planken.");
			}

			spend(r[1], n);
			inventory.merge("minecraft:" + name, n, Integer::sum);
			return msg(n + "x " + name + " gesmolten/gebakken in de oven.");
		}

		throw new IllegalArgumentException("Ik weet niet hoe ik '" + name + "' maak, of ik mis de spullen. Gebruik 'recepten' voor de lijst.");
	}

	// ---------------- kisten ----------------

	private JsonObject chest(Entity bot, ServerLevel level, JsonObject req) {
		int x = i(req, "x");
		int y = i(req, "y");
		int z = i(req, "z");

		if (!inReach(bot, x, y, z, REACH)) {
			throw new IllegalArgumentException("Die kist is te ver weg. Loop er eerst naartoe.");
		}

		BlockPos pos = new BlockPos(x, y, z);

		if (!(level.getBlockEntity(pos) instanceof Container box)) {
			throw new IllegalArgumentException("Daar staat geen kist (of iets anders waar spullen in kunnen).");
		}

		lookAt(bot, x + 0.5, y + 0.5, z + 0.5);
		String action = s(req, "actie", "bekijk");
		String id = normalizeBlock(s(req, "item", "x"));
		int count = req.has("aantal") ? Math.max(1, i(req, "aantal")) : 1;
		JsonObject o = new JsonObject();

		if (action.equals("pak")) {
			int left = count;

			for (int slot = 0; slot < box.getContainerSize() && left > 0; slot++) {
				ItemStack st = box.getItem(slot);

				if (!st.isEmpty() && BuiltInRegistries.ITEM.getKey(st.getItem()).toString().equals(id)) {
					int n = Math.min(left, st.getCount());
					st.shrink(n);
					left -= n;
				}
			}

			box.setChanged();

			if (left == count) {
				throw new IllegalArgumentException("Er zit geen " + id + " in.");
			}

			inventory.merge(id, count - left, Integer::sum);
			o.addProperty("bericht", (count - left) + "x " + id + " uit de kist gepakt.");
		} else if (action.equals("stop")) {
			int haveCount = inventory.getOrDefault(id, 0);

			if (haveCount < 1) {
				throw new IllegalArgumentException("Ik heb geen " + id + ".");
			}

			int left = Math.min(count, haveCount);
			int start = left;

			for (int slot = 0; slot < box.getContainerSize() && left > 0; slot++) {
				if (box.getItem(slot).isEmpty()) {
					ItemStack st = stackOf(id);
					int n = Math.min(left, st.getMaxStackSize());
					st.setCount(n);
					box.setItem(slot, st);
					left -= n;
				}
			}

			box.setChanged();

			if (left == start) {
				throw new IllegalArgumentException("De kist is vol.");
			}

			take(id, start - left);
			o.addProperty("bericht", (start - left) + "x " + id + " in de kist gestopt.");
		}

		Map<String, Integer> contents = new TreeMap<>();

		for (int slot = 0; slot < box.getContainerSize(); slot++) {
			ItemStack st = box.getItem(slot);

			if (!st.isEmpty()) {
				contents.merge(BuiltInRegistries.ITEM.getKey(st.getItem()).toString(), st.getCount(), Integer::sum);
			}
		}

		JsonObject cj = new JsonObject();

		for (Map.Entry<String, Integer> en : contents.entrySet()) {
			cj.addProperty(en.getKey(), en.getValue());
		}

		o.add("in_de_kist", cj);
		return o;
	}
}
