package claudebuddy;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.function.Supplier;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.minecraft.server.MinecraftServer;

/**
 * Heel klein HTTP servertje (alleen bereikbaar vanaf deze pc).
 * De Python MCP server stuurt hier JSON opdrachten naartoe.
 */
public final class Bridge {
	private final MinecraftServer server;
	private final Bot bot;
	private final int port;
	private volatile ServerSocket socket;
	private volatile boolean running;

	public Bridge(MinecraftServer server, Bot bot, int port) {
		this.server = server;
		this.bot = bot;
		this.port = port;
	}

	public void start() {
		try {
			socket = new ServerSocket(port, 20, InetAddress.getLoopbackAddress());
			running = true;
		} catch (Exception e) {
			ClaudeBuddy.LOGGER.error("Claude Buddy kon poort {} niet openen (draait er al een wereld?)", port, e);
			return;
		}

		Thread t = new Thread(this::acceptLoop, "ClaudeBuddy-Bridge");
		t.setDaemon(true);
		t.start();
		ClaudeBuddy.LOGGER.info("Claude Buddy luistert op 127.0.0.1:{}", port);
	}

	public void stop() {
		running = false;

		try {
			ServerSocket s = socket;

			if (s != null) {
				s.close();
			}
		} catch (Exception ignored) {
			// niks
		}
	}

	private void acceptLoop() {
		while (running) {
			try {
				Socket client = socket.accept();
				Thread t = new Thread(() -> handle(client), "ClaudeBuddy-Request");
				t.setDaemon(true);
				t.start();
			} catch (Exception e) {
				if (running) {
					ClaudeBuddy.LOGGER.warn("Claude Buddy verbinding fout: {}", e.toString());
				}
			}
		}
	}

	private void handle(Socket client) {
		try (Socket s = client) {
			s.setSoTimeout(15000);
			InputStream in = new BufferedInputStream(s.getInputStream());

			ByteArrayOutputStream head = new ByteArrayOutputStream();
			int state = 0;
			int c;

			while ((c = in.read()) != -1) {
				head.write(c);

				if (c == '\r') {
					state = (state == 2) ? 3 : 1;
				} else if (c == '\n') {
					state = (state == 1) ? 2 : (state == 3) ? 4 : 0;
				} else {
					state = 0;
				}

				if (state == 4) {
					break;
				}

				if (head.size() > 16384) {
					return;
				}
			}

			int length = 0;

			for (String line : head.toString(StandardCharsets.ISO_8859_1).split("\r\n")) {
				String lower = line.toLowerCase(Locale.ROOT);

				if (lower.startsWith("content-length:")) {
					length = Integer.parseInt(lower.substring("content-length:".length()).trim());
				}
			}

			if (length < 0 || length > 1_000_000) {
				return;
			}

			byte[] body = in.readNBytes(length);
			JsonObject response;

			try {
				String text = new String(body, StandardCharsets.UTF_8).trim();
				JsonObject request = text.isEmpty() ? new JsonObject() : JsonParser.parseString(text).getAsJsonObject();
				response = dispatch(request);
			} catch (Throwable t) {
				response = new JsonObject();
				response.addProperty("ok", false);
				response.addProperty("fout", String.valueOf(t.getMessage() != null ? t.getMessage() : t.toString()));
			}

			byte[] out = response.toString().getBytes(StandardCharsets.UTF_8);
			OutputStream os = s.getOutputStream();
			os.write(("HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: "
					+ out.length + "\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.ISO_8859_1));
			os.write(out);
			os.flush();
		} catch (Exception e) {
			ClaudeBuddy.LOGGER.debug("Claude Buddy request fout: {}", e.toString());
		}
	}

	private JsonObject dispatch(JsonObject request) throws Exception {
		String cmd = request.has("cmd") ? request.get("cmd").getAsString() : "status";

		if (cmd.equals("screenshot")) {
			return screenshot(request);
		}

		return onServerThread(() -> bot.handle(cmd, request));
	}

	private JsonObject onServerThread(Supplier<JsonObject> work) throws Exception {
		CompletableFuture<JsonObject> future = server.submit(work);
		return future.get(10, TimeUnit.SECONDS);
	}

	/** Eerst de goede kant op kijken (server), dan de client een foto laten maken. */
	private JsonObject screenshot(JsonObject request) throws Exception {
		JsonObject prepared = onServerThread(() -> bot.handle("kijk_naar_voor_foto", request));

		if (!prepared.get("ok").getAsBoolean()) {
			return prepared;
		}

		Function<java.util.UUID, CompletableFuture<String>> hook = ClaudeBuddy.screenshotHook;

		if (hook == null) {
			prepared.addProperty("ok", false);
			prepared.addProperty("fout", "Geen Minecraft-scherm gevonden om een foto mee te maken (dedicated server?).");
			return prepared;
		}

		Thread.sleep(150);
		String path = hook.apply(Bot.BOT_UUID).get(8, TimeUnit.SECONDS);
		JsonObject result = onServerThread(() -> bot.handle("status", new JsonObject()));
		result.addProperty("bestand", path);
		return result;
	}
}
