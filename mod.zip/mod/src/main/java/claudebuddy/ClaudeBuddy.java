package claudebuddy;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;

import com.mojang.brigadier.arguments.StringArgumentType;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClaudeBuddy implements ModInitializer {
	public static final String MOD_ID = "claudebuddy";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	/** Poort waarop de mod luistert (alleen op deze pc zelf, 127.0.0.1). */
	public static final int PORT = 25599;

	/**
	 * Wordt door de client-kant ingevuld. Maakt een screenshot vanuit de ogen van Claude
	 * en geeft het pad van het plaatje terug.
	 */
	public static volatile Function<UUID, CompletableFuture<String>> screenshotHook = null;

	private static volatile Bot bot;
	private static volatile Bridge bridge;

	@Override
	public void onInitialize() {
		ServerLifecycleEvents.SERVER_STARTED.register(server -> {
			bot = new Bot(server);
			bridge = new Bridge(server, bot, PORT);
			bridge.start();
		});

		ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
			Bridge b = bridge;
			bridge = null;
			bot = null;

			if (b != null) {
				b.stop();
			}
		});

		ServerTickEvents.END_SERVER_TICK.register(server -> {
			Bot b = bot;

			if (b != null) {
				try {
					b.tick();
				} catch (Throwable t) {
					LOGGER.error("Claude Buddy tick fout", t);
				}
			}
		});

		ServerMessageEvents.CHAT_MESSAGE.register((message, sender, boundChatType) -> {
			Bot b = bot;

			if (b != null) {
				b.onChat(sender.getName().getString(), message.signedContent());
			}
		});

		// creatief = geen schade, en met het schild omhoog houdt Claude klappen tegen
		ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
			Bot b = bot;
			return b == null || b.allowDamage(entity, source, amount);
		});

		// /gamemodeclaude c  = creatief (vliegen, onkwetsbaar, alle blokken),  /gamemodeclaude s = survival
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
				Commands.literal("gamemodeclaude").then(Commands.argument("modus", StringArgumentType.word()).executes(ctx -> {
					Bot b = bot;
					String text = b == null ? "Claude Buddy is nog niet gestart."
							: b.gameMode(StringArgumentType.getString(ctx, "modus"));
					ctx.getSource().sendSuccess(() -> Component.literal(text), false);
					return 1;
				}))));

		LOGGER.info("Claude Buddy geladen. Wacht op de MCP server op poort {}.", PORT);
	}
}
