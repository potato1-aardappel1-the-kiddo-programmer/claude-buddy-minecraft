package claudebuddy.capture.mixin;
import net.minecraft.client.Minecraft;
import claudebuddy.capture.BuddyCapture;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Minecraft.class)
public abstract class MinecraftFrameMixin {
    @Inject(method = "renderFrame(Z)V", at = @At(value = "INVOKE",
        target = "Lnet/minecraft/client/renderer/GameRenderer;update(Lnet/minecraft/client/DeltaTracker;)V"), require = 1)
    private void buddy$capture(boolean renderLevel, CallbackInfo ci) {
        BuddyCapture.beforeNormalFrame(renderLevel);
    }
}
