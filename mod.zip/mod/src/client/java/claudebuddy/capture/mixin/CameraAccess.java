package claudebuddy.capture.mixin;
import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
@Mixin(Camera.class)
public interface CameraAccess {
    @Accessor("eyeHeight") void buddy$eyeHeight(float value);
    @Accessor("eyeHeightOld") void buddy$eyeHeightOld(float value);
    @Accessor("fovModifier") void buddy$fovModifier(float value);
    @Accessor("oldFovModifier") void buddy$oldFovModifier(float value);
}
