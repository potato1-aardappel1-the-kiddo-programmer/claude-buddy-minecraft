package claudebuddy.capture.mixin;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.extract.LevelExtractor;
import net.minecraft.world.entity.Entity;
import claudebuddy.capture.BuddyCapture;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
@Mixin(LevelExtractor.class)
public abstract class LevelExtractorMixin {
    // Only the FOURTH Camera.entity() invocation is the LocalPlayer exclusion.
    // The earlier calls still hide the mannequin itself in first person.
    @Redirect(method = "extractVisibleEntities", at = @At(value = "INVOKE",
        target = "Lnet/minecraft/client/Camera;entity()Lnet/minecraft/world/entity/Entity;", ordinal = 3), require = 1)
    private Entity buddy$allowLocalPlayer(Camera camera) {
        return BuddyCapture.active() ? Minecraft.getInstance().player : camera.entity();
    }
}
