package claudebuddy.capture.mixin;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.state.level.PlayerRenderState;
import claudebuddy.capture.BuddyCapture;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "renderItemInHand", at = @At("HEAD"), cancellable = true, require = 1)
    private void buddy$hideHands(CameraRenderState camera, PlayerRenderState player,
                                GpuTextureView texture, CallbackInfo ci) {
        if (BuddyCapture.active()) ci.cancel();
    }
}
