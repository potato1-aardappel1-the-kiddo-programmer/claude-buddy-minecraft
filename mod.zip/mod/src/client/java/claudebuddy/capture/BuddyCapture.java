package claudebuddy.capture;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Camera;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.world.entity.Entity;
import claudebuddy.capture.mixin.CameraAccess;
import claudebuddy.capture.mixin.GameRendererAccess;

/** Vanilla 26.3 proof of concept; must be tested in game. */
public final class BuddyCapture {
    private record Request(UUID entity, Path file, CompletableFuture<Path> result) {}
    private static Request pending;
    private static boolean busy;
    private static boolean active;

    public static boolean active() { return active; }

    /** Safe to call from the server/bridge thread. Never block the client thread. */
    public static CompletableFuture<Path> request(UUID entity, Path file) {
        CompletableFuture<Path> result = new CompletableFuture<>();
        Minecraft.getInstance().execute(() -> {
            if (busy) {
                result.completeExceptionally(new IllegalStateException("Screenshot already pending"));
                return;
            }
            busy = true;
            pending = new Request(entity, file.toAbsolutePath(), result);
            result.whenComplete((path, error) -> Minecraft.getInstance().execute(() -> busy = false));
        });
        return result;
    }

    /** Called by MinecraftFrameMixin immediately before the normal camera update. */
    public static void beforeNormalFrame(boolean renderLevel) {
        if (active || pending == null || !renderLevel) return;
        Minecraft mc = Minecraft.getInstance();
        Request request = pending;
        pending = null;
        if (mc.level == null || mc.player == null || mc.gui.screen() != null || mc.gui.overlay() != null) {
            request.result.completeExceptionally(new IllegalStateException("Open an unobstructed world first"));
            return;
        }
        Entity target = null;
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity.getUUID().equals(request.entity)) { target = entity; break; }
        }
        if (target == null) {
            request.result.completeExceptionally(new IllegalStateException("Entity is not loaded on the client"));
            return;
        }
        var renderer = mc.gameRenderer;
        Camera originalCamera = renderer.mainCamera();
        CameraType originalType = mc.options.getCameraType();
        GameRendererAccess access = (GameRendererAccess) renderer;
        try {
            Files.createDirectories(request.file.getParent());
            Camera camera = new Camera();
            camera.setLevel(mc.level);
            camera.setEntity(target);
            ((CameraAccess) camera).buddy$eyeHeight(target.getEyeHeight());
            ((CameraAccess) camera).buddy$eyeHeightOld(target.getEyeHeight());
            ((CameraAccess) camera).buddy$fovModifier(1.0f);
            ((CameraAccess) camera).buddy$oldFovModifier(1.0f);
            access.buddy$camera(camera);
            mc.options.setCameraType(CameraType.FIRST_PERSON);
            active = true;
            renderer.update(mc.getDeltaTracker());
            renderer.extract(mc.getDeltaTracker(), true);
            renderer.gameRenderState().guiRenderState.reset();
            renderer.gameRenderState().guiRenderState.isHudHidden = true;
            renderer.render();
            // Queue readback BEFORE the normal player render overwrites this texture.
            Screenshot.takeScreenshot(renderer.mainRenderTarget(), image -> {
                try (image) {
                    image.writeToFile(request.file);
                    request.result.complete(request.file);
                } catch (Throwable error) {
                    request.result.completeExceptionally(error);
                }
            });
            // takeScreenshot itself queues a copy; submit AFTER queuing that copy.
            RenderSystem.getDevice().createCommandEncoder().submit();
        } catch (Throwable error) {
            request.result.completeExceptionally(error);
        } finally {
            access.buddy$camera(originalCamera);
            mc.options.setCameraType(originalType);
            active = false;
        }
        // Minecraft.renderFrame continues: update -> extract -> render -> present.
        // Consequently the auxiliary image is overwritten before presentation.
    }
}
