package claudebuddy.client;

import java.nio.file.Path;
import java.util.concurrent.TimeUnit;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.loader.api.FabricLoader;

import claudebuddy.ClaudeBuddy;
import claudebuddy.capture.BuddyCapture;

/**
 * Client-kant: maakt een foto vanuit de ogen van Claude, zodat Claude echt kan "zien".
 *
 * Het echte werk zit in BuddyCapture (bedacht door ChatGPT): die tekent vlak voor het normale
 * beeld stiekem 1 extra beeldje vanuit Claude. Dat komt nooit op het scherm, dus de speler
 * merkt er niks van. De speler zelf staat wel op de foto; zijn hand, hotbar en chat niet.
 */
public class ClaudeBuddyClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ClaudeBuddy.screenshotHook = uuid -> BuddyCapture.request(
				uuid,
				FabricLoader.getInstance().getGameDir().resolve("claudebuddy").resolve("kijk.png")
		).orTimeout(6, TimeUnit.SECONDS).thenApply(Path::toString);
	}
}
