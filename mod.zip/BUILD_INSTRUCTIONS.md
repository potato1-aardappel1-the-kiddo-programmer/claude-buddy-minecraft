# Build instructions (Claude Buddy mod)

Fabric mod for Minecraft 26.3. Needs Java 25 and Gradle (wrapper included).

1. In the `mod` folder run: `./gradlew build`  (Windows: `.\gradlew build`)
2. The result is `mod/build/libs/claudebuddy-1.0.0.jar`. Return that jar.

Do not change the package name (`claudebuddy`), the mod id or the version.
The code was renamed from an older package; only fix real compile errors, change nothing else.
